package Main;

import ca1.data.structures.and.algorithms.AmountOfFloors;
import ca1.data.structures.and.algorithms.Floor;

import ca1.data.structures.and.algorithms.BufferedImageLoader;
import ca1.data.structures.and.algorithms.EdgeB;
import ca1.data.structures.and.algorithms.EdgeT;
import ca1.data.structures.and.algorithms.Elevator;
import ca1.data.structures.and.algorithms.ElevatorOwn;
import ca1.data.structures.and.algorithms.FloorEdge;
import ca1.data.structures.and.algorithms.Handler;
import ca1.data.structures.and.algorithms.ID;
import ca1.data.structures.and.algorithms.InitialConditions;
import ca1.data.structures.and.algorithms.MouseClick;
import ca1.data.structures.and.algorithms.User;
import ca1.data.structures.and.algorithms.Window;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

/**
 * Class which initialises everything used for update loop and creation of
 * objects
 *
 * @author angel
 */
public class Main extends Canvas implements Runnable {

    private Thread thread;
    private boolean running = false;
    private Handler handler;
    private ElevatorOwn eleO;
    private User user;

    public static int state;//if 0 the base case will be loaded, if 1 my own way of the elevator will be working

    public static final int HEIGHT = 1000;//width and height of the frame
    public static final int WIDTH = 1157;

    private static int startX = 550;//starting coordinates of the elevator
    private static int startY = 950;

    public static int[] array = new int[20];//array containing the amount of waiting users in the elevator

    public static boolean paused = false;//decides whether the program is running or not

    public static BufferedImage elevator;//image for elevator
    public static BufferedImage person;//image for user

    public Main() {
        handler = new Handler();

        BufferedImageLoader loader = new BufferedImageLoader();

        if (AmountOfFloors.baseCaseChk.isSelected()) {//decides what the state of the program will be depending on the value of the variable(which tick-box is ticked)
            state = 0;
        } else {
            state = 1;
        }

        elevator = loader.loadImage("/ele.png");
        person = loader.loadImage("/person.png");

        addObjects();

        this.addMouseListener(new MouseClick(handler, eleO));//mouse clicks
        new Window(WIDTH, HEIGHT, "Elevator", this);//makes the frame

        start();//starts the thread
    }

    //start up of thread
    private void start() {
        running = true;//when running is true, the run() method is going to be executed
        thread = new Thread(this);
        thread.start();
    }

    //end of thread
    private void stop() {
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    //game loop method which is running the program constantly
    public void run() {//updates 60 times a second

        //every comment that has a '//debug' on it is used for the monitoring of frames and ticks of the game while it is running 
        //does not contribute to the functionality of the game itselfs
        this.requestFocus();//requests focus of window automatically
        long lastTime = System.nanoTime();//takes the current time from the system clock niin nano seconds
        final double amountOfTicks = 150; //150 ticks
        double ns = 1000000000 / amountOfTicks;//1 billion is 1 second in nanoseconds
        double delta = 0;//variable used to catch up on time
        long timer = System.currentTimeMillis();//takes current time of system on milliseconds

        int updates = 0;//ticks the game is//debug
        int frames = 0;//frames per second the game is running at//debug

        while (running) {//game loop
            long now = System.nanoTime();//takes the current system clock time in nanoseconds
            delta += (now - lastTime) / ns;//uses delta to see the difference and catch up
            lastTime = now;//setting last time to equal the time now
            if (delta >= 1) {
                tick();
                updates++;//debug
                delta--;
            }
            render();
            frames++;//debug

            //debug
            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;//adds 1000 so that it runs this code every second
                //(1000 milliseconds are 1 second)
//                System.out.println("Frames " + frames + "  |  Ticks " + updates);//prints off FPS in the 

                //console window
                frames = 0;//resets frames and updates so that  
                updates = 0;//they don't add up with the previous values
            }
        }
        stop();

    }

    /**
     * method used to update listed objects and their classes while the game is
     * running
     */
    public void tick() {
        handler.tick();
    }

    /**
     * Method used to render all of the graphics and buffer next frames
     */
    public void render() {
        BufferStrategy bs = this.getBufferStrategy();

        if (bs == null) {
            this.createBufferStrategy(3);//preloading next frames, has 2 frames in queue ready to show(buffers the next two frames)
            return;
        }

        Graphics g = bs.getDrawGraphics();

        g.setColor(Color.lightGray);//sets the colour to black and fills the window in the specified colour
        g.fillRect(0, 0, WIDTH, HEIGHT);
//        g.drawImage(background, 0, 0, this);

//           
        handler.render(g);

        g.setColor(Color.black);

        //draws the floor numbers and the corresponding amount of users per floor
        g.drawString(String.valueOf(array[19]) + "                            20", 510, 48 - 20);
        g.drawString(String.valueOf(array[18]) + "                            19", 510, 96 - 20);
        g.drawString(String.valueOf(array[17]) + "                            18", 510, 144 - 20);
        g.drawString(String.valueOf(array[16]) + "                            17", 510, 192 - 20);
        g.drawString(String.valueOf(array[15]) + "                            16", 510, 240 - 20);
        g.drawString(String.valueOf(array[14]) + "                            15", 510, 288 - 20);
        g.drawString(String.valueOf(array[13]) + "                            14", 510, 336 - 20);
        g.drawString(String.valueOf(array[12]) + "                            13", 510, 384 - 20);
        g.drawString(String.valueOf(array[11]) + "                            12", 510, 432 - 20);
        g.drawString(String.valueOf(array[10]) + "                            11", 510, 480 - 20);
        g.drawString(String.valueOf(array[9]) + "                            10", 510, 528 - 20);
        g.drawString(String.valueOf(array[8]) + "                             9", 510, 576 - 20);
        g.drawString(String.valueOf(array[7]) + "                             8", 510, 624 - 20);
        g.drawString(String.valueOf(array[6]) + "                             7", 510, 672 - 20);
        g.drawString(String.valueOf(array[5]) + "                             6", 510, 720 - 20);
        g.drawString(String.valueOf(array[4]) + "                             5", 510, 768 - 20);
        g.drawString(String.valueOf(array[3]) + "                             4", 510, 816 - 20);
        g.drawString(String.valueOf(array[2]) + "                             3", 510, 864 - 20);
        g.drawString(String.valueOf(array[1]) + "                             2", 510, 912 - 20);
        g.drawString(String.valueOf(array[0]) + "                             1", 510, 960 - 20);

        g.dispose();//closes Graphics object
        bs.show();//renders the buffer

    }

    private void takeValues() {
        //method to take the values from the InitialConditions frame and plot them to the corresponding variables

        int floor1 = InitialConditions.slider1.getValue();
        int floor2 = InitialConditions.slider2.getValue();
        int floor3 = InitialConditions.slider3.getValue();
        int floor4 = InitialConditions.slider4.getValue();
        int floor5 = InitialConditions.slider5.getValue();
        int floor6 = InitialConditions.slider6.getValue();
        int floor7 = InitialConditions.slider7.getValue();
        int floor8 = InitialConditions.slider8.getValue();
        int floor9 = InitialConditions.slider9.getValue();
        int floor10 = InitialConditions.slider10.getValue();
        int floor11 = InitialConditions.slider11.getValue();
        int floor12 = InitialConditions.slider12.getValue();
        int floor13 = InitialConditions.slider13.getValue();
        int floor14 = InitialConditions.slider14.getValue();
        int floor15 = InitialConditions.slider15.getValue();
        int floor16 = InitialConditions.slider16.getValue();
        int floor17 = InitialConditions.slider17.getValue();
        int floor18 = InitialConditions.slider18.getValue();
        int floor19 = InitialConditions.slider19.getValue();
        int floor20 = InitialConditions.slider20.getValue();

        makeInitialUsers(floor1, 0, 912, 0);
        makeInitialUsers(floor2, 0, 864, 1);
        makeInitialUsers(floor3, 0, 816, 2);
        makeInitialUsers(floor4, 0, 768, 3);
        makeInitialUsers(floor5, 0, 720, 4);
        makeInitialUsers(floor6, 0, 672, 5);
        makeInitialUsers(floor7, 0, 624, 6);
        makeInitialUsers(floor8, 0, 576, 7);
        makeInitialUsers(floor9, 0, 528, 8);
        makeInitialUsers(floor10, 0, 480, 9);
        makeInitialUsers(floor11, 0, 432, 10);
        makeInitialUsers(floor12, 0, 384, 11);
        makeInitialUsers(floor13, 0, 336, 12);
        makeInitialUsers(floor14, 0, 288, 13);
        makeInitialUsers(floor15, 0, 240, 14);
        makeInitialUsers(floor16, 0, 192, 15);
        makeInitialUsers(floor17, 0, 144, 16);
        makeInitialUsers(floor18, 0, 96, 17);
        makeInitialUsers(floor19, 0, 48, 18);
        makeInitialUsers(floor20, 0, 0, 19);

    }

    private void makeInitialUsers(int amount, int x, int y, int pos) {
        //method to add an object to the screen depending on the parameters of this method
        for (int i = 0; i < amount; i++) {
            handler.addObject(new User(x, y, ID.user, this, handler, eleO));
            array[pos] += 1;//adding one to the amount of users on the corresponding position in the array
        }
    }

    private void addObjects() {
        //method which makes the adding of the initial objects more compact

        //addition of the 20 different floors
        handler.addObject(new Floor(0, 0, ID.floor20, 550, 48));
        handler.addObject(new Floor(0, 48, ID.floor19, 550, 48));
        handler.addObject(new Floor(0, 96, ID.floor18, 550, 48));
        handler.addObject(new Floor(0, 144, ID.floor17, 550, 48));
        handler.addObject(new Floor(0, 192, ID.floor16, 550, 48));
        handler.addObject(new Floor(0, 240, ID.floor15, 550, 48));
        handler.addObject(new Floor(0, 288, ID.floor14, 550, 48));
        handler.addObject(new Floor(0, 336, ID.floor13, 550, 48));
        handler.addObject(new Floor(0, 384, ID.floor12, 550, 48));
        handler.addObject(new Floor(0, 432, ID.floor11, 550, 48));
        handler.addObject(new Floor(0, 480, ID.floor10, 550, 48));
        handler.addObject(new Floor(0, 528, ID.floor9, 550, 48));
        handler.addObject(new Floor(0, 576, ID.floor8, 550, 48));
        handler.addObject(new Floor(0, 624, ID.floor7, 550, 48));
        handler.addObject(new Floor(0, 672, ID.floor6, 550, 48));
        handler.addObject(new Floor(0, 720, ID.floor5, 550, 48));
        handler.addObject(new Floor(0, 768, ID.floor4, 550, 48));
        handler.addObject(new Floor(0, 816, ID.floor3, 550, 48));
        handler.addObject(new Floor(0, 864, ID.floor2, 550, 48));
        handler.addObject(new Floor(0, 912, ID.floor1, 550, 48));

        //floorEdge class is used to update the addition and removal of a user 
        //to and from the elevator respectively, there is one and the end of each floor
        for (int i = 0; i <= 912; i += 48) {
            handler.addObject(new FloorEdge(550, i, ID.floorEdge));
        }

        //two edges of the screen (top and bottom) which wil later be used in 
        //the own solution to be moved dynamically to improve performance of the elevator
        EdgeT edgeT = new EdgeT(0, 960 - 48 * Integer.parseInt(AmountOfFloors.submitTxt.getText()), ID.edgeT, this, handler, eleO);
        EdgeB edgeB = new EdgeB(0, 958, ID.edgeB, this, handler, eleO);

        handler.addObject(edgeT);
        handler.addObject(edgeB);

        if (state == 0) {//if the base case check box is checked, base case will run
            handler.addObject(new Elevator(startX, startY, ID.elevator, this, this.handler, user));
        }
        if (state == 1) {//if the own case check box is checked, own case will run
            //initialisation because I had to use it in different classes, and it was giving me a NullPointerExeption
            eleO = new ElevatorOwn(startX, startY - 400, ID.elevatorO, this, this.handler, user);
            handler.addObject(eleO);//needed to separate the declaration and 
//            handler.addObject(new EdgeB(0, 958, ID.edgeB, this, handler, eleO));
        }
        takeValues();

    }

    public static void main(String[] args) {
        AmountOfFloors amountOfFloors = new AmountOfFloors();
        amountOfFloors.setVisible(true);
        //specifying the amount of floors at first so I know how many floor I can allow the user to use and edit
    }
}
