/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author angel
 */
public class Floor extends Objects {


    private int width;
    private int height;

    public static int count1 = 0;

    private final int x;
    private final int y;

    public Floor(int x, int y, ID id, int width, int height) {
        super(x, y, id);

        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

    }

    public void tick() {
    }

    public void render(Graphics g) {
        g.setColor(Color.black);
        g.drawRect(x, y, width * 2 + 40, height);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 1200, 48);
    }
    public Rectangle getBoundsDown() {
        return new Rectangle(x, y, 1200, 48);
    }

}
