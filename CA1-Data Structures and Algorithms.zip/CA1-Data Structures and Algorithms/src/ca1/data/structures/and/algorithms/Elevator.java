/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author angel
 */
public class Elevator extends Objects {

    private Handler handler;
    private Main main;
    private User user;

    Random r = new Random();

    public static int currentFloor = 1;//starts at the bottom
    int amountOnFloor;

    int direction = 1;//1 will be when the elevator is moving up and 0 when 
    //moving down

    int state = 0;//0 for going up, 1 for going down

    public static int capacity = 10;//only 10 people are able to get on

    private BufferedImage ele;

    public Elevator(int x, int y, ID id, Main main, Handler handler, User user) {
        super(x, y, id);

        this.x = x;
        this.y = y;
        this.main = main;
        this.handler = handler;
        this.user = user;

        SpriteSheet ss = new SpriteSheet(Main.elevator);//initialising the image in the constructor
        ele = ss.grabImage(1, 1, 40, 48);

    }

    public void tick() {
        y += velY;
        x += velX;
        
        System.out.println("y = " + y);

        collision();
        if (direction == 0) {
            velY = 2;
        }
        if (direction == 1) {
            velY = -2;
        }
//        mechanismSimple(this);
        currentFloor = checkFloor(0, y);
//        amountOnFloor = checkUsers(0, currentFloor);
//        System.out.println("floor = " + currentFloor);
        if (amountOnFloor > 0) {
            amountOnFloor--;
//            System.out.println(amountOnFloor);
        }
    }

    public void render(Graphics g) {
//        g.setColor(Color.red);
//        g.drawRect(x, y, 50, 50);
        g.drawImage(ele, x, y, null);
        g.drawString(String.valueOf(capacity), x + 13, y + 35);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 40, 48);
    }

    public void mechanismSimple(Elevator elevator) {//mechanism for the simple elevator
        //mechanism which reverts the direction of movement when the elevator object collides with the edge object

    }

    public int checkFloor(int startFloor, int y) {
        int floor = startFloor;
        for (int i = 0; i <= 912; i += 48) {
            if (y >= i) {
                floor++;
            } else {
                break;
            }
        }
        return floor;
    }

    public int checkUsers(int floorNum) {

        return Main.array[floorNum - 1];
    }

    public void addToElevator(int floorNum) {
        if (amountOnFloor > 0) {
            if (capacity <= 10) {
                for (int j = 0; j < handler.object.size(); j++) {
                    Objects tempObject = handler.object.get(j);

                    if (tempObject.getID() == ID.user) {
                        tempObject.state = 2;
                        break;
                    }
                }
            }
        }
    }

    public void mechanismSelf(Elevator elevator) {//mechanism for the self made elevator

    }

    private void collision() {
        //collision detection method
        for (int i = 0; i < handler.object.size(); i++) {

            Objects tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.edgeB) {//if the player interacts with a block object

                if (getBounds().intersects(tempObject.getBounds())) {//player cannot go beyond this object
                    System.out.println(tempObject.getID() + "edgeB");
                    direction = 1;
                }
            }
            if (tempObject.getID() == ID.edgeT) {//if the player interacts with a block object

                if (getBounds().intersects(tempObject.getBounds())) {//player cannot go beyond this object
                    System.out.println(tempObject.getID() + "edgeT");
                    direction = 0;
                }
            }

            if (tempObject.getID() == ID.floorEdge) {

                if (getBounds().intersects(tempObject.getBounds())) {

                    amountOnFloor = checkUsers(currentFloor);
                    addToElevator(currentFloor);

                }
            }
        }
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public int getY() {
        return this.y;
    }

    public int getVelY() {
        return this.velY;
    }

}
