package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 * Class which makes an object acting as the edges of the floors Changes y
 * coordinates dynamically if in the own solution state
 *
 * @author angel
 */
public class EdgeT extends Objects {

    private ElevatorOwn eleO;
    private Handler handler;

    public int max;

    public EdgeT(int x, int y, ID id, Main main, Handler handler, ElevatorOwn eleO) {
        super(x, y, id);

        this.eleO = eleO;
        this.handler = handler;

        max = 1;
    }

    public void tick() {
//
//        if (ElevatorOwn.direction != 1) {
        this.y = 960 - (checkMax() * 48);
//        }
    }

    public void render(Graphics g) {
        g.setColor(Color.blue);
        g.drawRect(x, y, 1200, 2);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 1200, 2);
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    private int checkMax() {
        //used to check the maximum floor from all users inside the elevator

        int max1 = checkMaxFloor();
        int max2 = checkMaxGoingTo();

        if (max1 > max2) {
            max = max1;
            return max;
        } else {
            max = max2;
            return max;
        }
    }

    private int checkMaxFloor() {
        int i;
        for (i = 19; i >= 0; i--) {
            if (Main.array[i] > 0) {
                break;
            }
        }
        return (i + 1);
    }

    private int checkMaxGoingTo() {
        if (ElevatorOwn.insideArray[9] == 0) {
            return Integer.parseInt(AmountOfFloors.submitTxt.getText());
        } else {
            return ElevatorOwn.insideArray[9];
        }
    }
}
