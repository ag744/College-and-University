package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Arrays;

/**
 * Class which makes an object acting as the bottom edge of the floors Changes y
 * coordinates dynamically if in the own solution state
 *
 * @author angel
 */
public class EdgeB extends Objects {

    private ElevatorOwn eleO;
    private Handler handler;
    public int min; //used to set the initial minimum as the maximum floor 
    //so that it will always change regardless of the first given value

    public EdgeB(int x, int y, ID id, Main main, Handler handler, ElevatorOwn eleO) {
        super(x, y, id);

        this.eleO = eleO;
        this.handler = handler;

        min = 1;
        counter = 1;//counter here will be used to allocate the position of the bottom edge by floor

    }

    public void tick() {
//        if (ElevatorOwn.direction != 0) {
            int minimum = checkMin() - 1;
            this.y = 960 - (minimum * 48);//changes the y value of the object dynamically
            //according to the checkMin() method
//        }

        System.out.println(Arrays.toString(ElevatorOwn.insideArray));
    }

    public void render(Graphics g) {
        g.setColor(Color.green);
        g.drawRect(x, y, 1200, 2);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 1200, 2);
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    private int checkMin() {
        //used to check the minimum floor from all users inside the elevator

        int min1 = checkMinFloor();
        int min2 = checkMinGoingTo();

        if (min1 < min2) {
            min = min1;
//            System.out.println("countermin1 = " + counter);
            System.out.println("min1 = " + min);
            return min;
        } else {
            min = min2;
//            System.out.println("countermin2 = " + counter);
            System.out.println("min2 = " + min);
            return min;
        }
    }

    private int checkMinFloor() {
        //method to loop through the array in Main containing the amount of 
        //users per floor, returning the minimum floor at which there are users

        int tempMin = 20;
        for (int i = 0; i < Main.array.length; i++) {

            if (Main.array[i] != 0) {
                tempMin = i;
                break;
            }
        }
        return tempMin;
    }

    private int checkMinGoingTo() {
        int tempMin = 1;

        for (int i = 0; i < ElevatorOwn.insideArray.length; i++) {
            if (ElevatorOwn.insideArray[i] != 0) {
                tempMin = ElevatorOwn.insideArray[i];
                break;
            }
        }
        return tempMin;
    }
}
