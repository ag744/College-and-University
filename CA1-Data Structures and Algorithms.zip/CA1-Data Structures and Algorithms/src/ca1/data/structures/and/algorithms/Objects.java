/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author angel
 */
public abstract class Objects {

    protected int x;
    
    protected int counter;
    
    protected int state;

    protected int y;

    protected ID id;

    protected int velX;

    protected int velY;
    
    /**
     * constructor used to indicate parameters refer to protected values of this
     * class
     *
     * @param x
     * @param y
     * @param id
     */
    public Objects(int x, int y, ID id) {
        this.x = x;
        this.y = y;
        this.id = id;

    }

    /**
     * used to update the object
     */
    public abstract void tick();

    /**
     * used to render graphics of the object
     *
     * @param g
     */
    public abstract void render(Graphics g);

    /**
     * used for collision detection
     *
     * @return
     */
    public abstract Rectangle getBounds();

    /**
     * getters and setters for the protected values
     *
     * @param id
     */
    public void setID(ID id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public ID getID() {
        return id;
    }

    /**
     *
     * @return
     */
    public int getX() {
        return x;
    }

    /**
     *
     * @return
     */
    public int getY() {
        return y;
    }

    /**
     *
     * @return
     */
    public int getVelX() {
        return velX;
    }

    /**
     *
     * @return
     */
    public int getVelY() {
        return velY;
    }

    /**
     *
     * @param x
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     *
     * @param y
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     *
     * @param velX
     */
    public void setVelX(int velX) {
        this.velX = velX;
    }

    /**
     *
     * @param velY
     */
    public void setVelY(int velY) {
        this.velY = velY;
    }

}
