/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author angel
 */
public class MouseClick extends MouseAdapter {

    private Handler handler;
    private Main main;
    private ElevatorOwn eleO;

    public MouseClick(Handler handler, ElevatorOwn eleO) {

        this.handler = handler;
        this.eleO = eleO;
    }

    /**
     * when the player presses a button on the mouse
     *
     * @param e when the user presses Button3 of the mouse (right click by
     * default)
     */
    @Override
    public void mousePressed(MouseEvent e) {

        int mx = (int) e.getX();//mouse x coordinate
        int my = (int) e.getY();//mouse y coordinate

        int floorNum;

        for (int i = 0; i < handler.object.size(); i++) {//loop through the ArrayList
            Objects tempObject = handler.object.get(i);
            if (e.getButton() == MouseEvent.BUTTON1) {//if the button clicked is the left button of the mouse
                if (tempObject.getID() == ID.floor1) {

                    floorNum = my / 48;

                    if (my > 0 && my <= 48) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[19]++;
//                            System.out.println(String.valueOf(Main.floor1));
                    }
                    if (my > 48 && my <= 96) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));

                        Main.array[18]++;
                    }
                    if (my > 96 && my <= 144) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[17]++;
                    }
                    if (my > 144 && my <= 192) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[16]++;
                    }
                    if (my > 192 && my <= 240) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[15]++;
                    }
                    if (my > 240 && my <= 288) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[14]++;
                    }
                    if (my > 288 && my <= 336) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[13]++;
                    }
                    if (my > 336 && my <= 384) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[12]++;
                    }
                    if (my > 384 && my <= 432) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[11]++;
                    }
                    if (my > 432 && my <= 480) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[10]++;
                    }
                    if (my > 480 && my <= 528) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[9]++;
                    }
                    if (my > 528 && my <= 576) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[8]++;
                    }
                    if (my > 576 && my <= 624) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[7]++;
                    }
                    if (my > 624 && my <= 672) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[6]++;
                    }
                    if (my > 672 && my <= 720) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[5]++;
                    }
                    if (my > 720 && my <= 768) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[4]++;
                    }
                    if (my > 768 && my <= 816) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[3]++;
                    }
                    if (my > 816 && my <= 864) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[2]++;
                    }
                    if (my > 864 && my <= 912) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[1]++;
                    }
                    if (my > 912 && my <= 960) {

                        handler.addObject(new User(0, floorNum * 48, ID.user, main, handler, eleO));
                        Main.array[0]++;
                    }

                }
            }

        }
    }
}
