/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author angel
 */
public class User extends Objects {

    BufferedImage person;

    public ID tempID;

    public int userState;
    //0 will be the initial state(waiting)
    //1 will be in the elevator
    //2 will be the done state

    private int yParam;

    private Handler handler;
    private ElevatorOwn eleO;

    Random r = new Random();
    int prevY;
    int efficiencyCounter = 0;

    public User(int x, int y, ID id, Main main, Handler handler, ElevatorOwn eleO) {
        super(x, y, id);

        this.x = x;
        this.y = y;
        this.handler = handler;
        this.eleO = eleO;
        userState = this.state;

        yParam = 20;
        tempID = randomiseID(r, Integer.parseInt(AmountOfFloors.submitTxt.getText()));
//        System.out.println("tempID = " + tempID);

        SpriteSheet ss = new SpriteSheet(Main.person);//initialising the image in the constructor
        person = ss.grabImage(1, 1, 20, 48);

        prevY = this.y;
    }

    public void tick() {
        collision();

        if (Math.abs(this.y - prevY) >= 48) {
            if (prevY >= this.y) {
                efficiencyCounter++;
//                System.out.println("efficiencyCounter = " + efficiencyCounter);
                prevY -= 48;
            }

            if (prevY < this.y) {
                efficiencyCounter++;
//                System.out.println("efficiencyCounter = " + efficiencyCounter);
                prevY += 48;
            }
        }

        if (userState == 0) {
            if (x <= 530) {
                x += 15;
            }
        }

        if (userState == 1) {
            y += velY;
        }

        if (userState == 2) {

            if (x < 1200) {
                x += 5;
            }
            if (x > 900) {
                System.out.println("efficiencyCounter = " + efficiencyCounter);
                handler.removeObject(this);
            }
        }

    }

    public void render(Graphics g) {
        g.drawImage(person, x, y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y + yParam, 40, 5);
    }

    public Rectangle getBigBounds() {
        return new Rectangle(x, y, 20, 48);
    }

    private ID randomiseID(Random r, int limit) {
        ID temp;

        int num = r.nextInt(limit);

        switch (num) {
            case 1:
                temp = ID.floor2;
                this.counter = 2;
                break;
            case 2:
                temp = ID.floor3;
                this.counter = 3;
                break;
            case 3:
                temp = ID.floor4;
                this.counter = 4;
                break;
            case 4:
                temp = ID.floor5;
                this.counter = 5;
                break;
            case 5:
                temp = ID.floor6;
                this.counter = 6;
                break;
            case 6:
                temp = ID.floor7;
                this.counter = 7;
                break;
            case 7:
                temp = ID.floor8;
                this.counter = 8;
                break;
            case 8:
                temp = ID.floor9;
                this.counter = 9;
                break;
            case 9:
                temp = ID.floor10;
                this.counter = 10;
                break;
            case 10:
                temp = ID.floor11;
                this.counter = 11;
                break;
            case 11:
                temp = ID.floor12;
                this.counter = 12;
                break;
            case 12:
                temp = ID.floor13;
                this.counter = 13;
                break;
            case 13:
                temp = ID.floor14;
                this.counter = 14;
                break;
            case 14:
                temp = ID.floor15;
                this.counter = 15;
                break;
            case 15:
                temp = ID.floor16;
                this.counter = 16;
                break;
            case 16:
                temp = ID.floor17;
                this.counter = 17;
                break;
            case 17:
                temp = ID.floor18;
                this.counter = 18;
                break;
            case 18:
                temp = ID.floor19;
                this.counter = 19;
                break;
            case 19:
                temp = ID.floor20;
                this.counter = 20;
                break;
            default:
                temp = ID.floor1;
                this.counter = 1;
                break;
        }

        return temp;
    }

    public int checkFloor(int startFloor, int y) {
        int floor = startFloor;

        for (int i = 0; i <= 912; i += 48) {
            if (y >= i) {
                floor++;
            } else {
                break;
            }
        }
        return floor;
    }

    private void collision() {
        //collision detection method

        int elevatorDirection = 0;

        for (int i = 0; i < handler.object.size(); i++) {

            Objects tempObject = handler.object.get(i);

            if (userState == 0) {
                if (tempObject.getID() == ID.elevator) {
                    if (getBounds().intersects(tempObject.getBounds())) {
                        if (Elevator.capacity <= 10) {
                            if (Elevator.capacity > 0) {

                                elevatorDirection = tempObject.state;
                                velY = tempObject.getVelY();
                                velX = 0;
                                Main.array[19 - checkFloor(-1, y)]--;
                                x = 560;
                                y = tempObject.getY();
                                yParam = 32;
                                userState = 1;
                                Elevator.capacity -= 1;

                            }
                        }
                    }
                }
                if (tempObject.getID() == ID.elevatorO) {
                    if (getBounds().intersects(tempObject.getBounds())) {
                        if (ElevatorOwn.capacity <= 10) {
                            if (ElevatorOwn.capacity > 0) {
                                elevatorDirection = tempObject.state;
                                velY = tempObject.getVelY();
                                velX = 0;
                                Main.array[20 - checkFloor(0, y)]--;
                                x = 560;
                                y = tempObject.getY();
                                yParam = 32;
                                userState = 1;
                                
                                eleO.addToInsideArray(this.counter);
                                int[] test = ElevatorOwn.insideArray;
                                ElevatorOwn.capacity -= 1;
                            }
                        }
                    }
                }
            }
            if (userState == 1) {
                if (tempObject.getID() == tempID) {
                    if (getBounds().intersects(tempObject.getBounds())) {
                        velY = 0;
                        velX = 0;
                        x = 600;
                        userState = 2;
                        if (elevatorDirection == 0) {
                            y = tempObject.getY();
//                            System.out.println("test");
                        }
                        if (Main.state == 0) {
                            Elevator.capacity += 1;
                        } else {
                            eleO.removeFromInsideArray(this.counter);
                            ElevatorOwn.capacity += 1;
                        }
                    }
                }
                if (tempObject.getID() == ID.elevatorO) {
                    if (getBounds().intersects(tempObject.getBounds())) {
                        velY = tempObject.getVelY();
                    }
                }
            }
            if (tempObject.getID() == ID.edgeB) {
                if (getBigBounds().intersects(tempObject.getBounds())) {
                    //player cannot go beyond this object
                    velY = -2;
                }
            }
            if (tempObject.getID() == ID.edgeT) {
                if (getBigBounds().intersects(tempObject.getBounds())) {
                    //player cannot go beyond this object
                    velY = 2;
                }
            }

        }
    }

}
