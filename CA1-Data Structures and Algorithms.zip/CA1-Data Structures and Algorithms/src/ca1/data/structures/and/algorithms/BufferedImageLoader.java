/*
 * Class used to load images of type BufferedImage
 */
package ca1.data.structures.and.algorithms;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
 *
 * @author angel
 */
public class BufferedImageLoader {
    
    private BufferedImage image;
    
    public BufferedImage loadImage(String path){
        
        try {
            image = ImageIO.read(getClass().getResource(path));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return image;
    }
    
}
