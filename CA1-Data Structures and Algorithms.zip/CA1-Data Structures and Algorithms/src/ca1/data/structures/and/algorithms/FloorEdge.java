/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author angel
 */
public class FloorEdge extends Objects {

    public FloorEdge(int x, int y, ID id) {
        super(x, y, id);

        this.x = x;
        this.y = y;
        this.id = id;
    }

    public void tick() {

    }

    public void render(Graphics g) {
        g.setColor(Color.red);
        g.drawLine(x, y, x + 38, y);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 38, 1);
    }


}
