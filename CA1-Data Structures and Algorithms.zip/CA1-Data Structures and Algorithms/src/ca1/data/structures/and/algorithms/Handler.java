package ca1.data.structures.and.algorithms;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 *
 * @author angel
 */
public class Handler {

    LinkedList<Objects> object = new LinkedList<>();
    //LinkedList was giving me problems as it was multiplying the list size 
    //everytime i add an object, so i replaced it with ArrayList

    /**
     * used to update every object
     */
    public void tick() {

        for (int i = 0; i < object.size(); i++) {//loops through all of the objects
            Objects tempObject = object.get(i);

            tempObject.tick();//runs the object's tick() method
        }

    }

    /**
     * used to render every object
     *
     * @param g
     */
    public void render(Graphics g) {

        for (int i = 0; i < object.size(); i++) {//loops through all of the objects
            Objects tempObject = object.get(i);

            tempObject.render(g);//runs the object's render() method
        }
    }

    /**
     * adding an object
     *
     * @param Object
     */
    public void addObject(Objects Object) {
        object.add(Object);

    }

    /**
     * removing an object
     *
     * @param Object
     */
    public void removeObject(Objects Object) {
        object.remove(Object);
    }

    /**
     * removing all objects in the linked list
     *
     * @param object
     */
    public void removeAll(ArrayList<Objects> object) {
        object.clear();
    }

    
}
