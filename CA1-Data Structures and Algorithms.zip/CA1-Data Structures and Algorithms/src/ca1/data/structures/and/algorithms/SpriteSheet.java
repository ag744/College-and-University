package ca1.data.structures.and.algorithms;

import java.awt.image.BufferedImage;

/**
 * Class used to trim images passed through. Useful when there are many objects
 * with small images (e.g. instead of having 20 images for 20 enemies, there is
 * 1 image which is divided into 20 sections)
 *
 * @author Angel
 */
public class SpriteSheet {

    private BufferedImage image;

    public SpriteSheet(BufferedImage image) {
        this.image = image;
    }

    /**
     * trims the image which uses this method.
     *
     * @param column number which denotes the column number (every 32 pixels)
     * @param row number which denotes the row number (every 32 pixels)
     * @param width the width of the subimage
     * @param height the height of the subimage
     * @return return the subimage to be used
     */
    public BufferedImage grabImage(int column, int row, int width, int height) {
        return image.getSubimage(column * 32 - 32, row * 32 - 32, width, height);
    }

}