/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

/**
 *
 * @author angel
 */
public enum ID {

    floor1(),
    floor2(),
    floor3(),
    floor4(),
    floor5(),
    floor6(),
    floor7(),
    floor8(),
    floor9(),
    floor10(),
    floor11(),
    floor12(),
    floor13(),
    floor14(),
    floor15(),
    floor16(),
    floor17(),
    floor18(),
    floor19(),
    floor20(),
    elevator(),
    elevatorO(),
    drawer(),
    user(),
    edgeT(),
    edgeB(),
    floorEdge(),
    movingUser(),
    doneUser();

    static int parseID(ID tempID) {
        int intID;

        switch (tempID) {

            case floor2:
                intID = 2;
                break;
            case floor3:
                intID = 3;
                break;
            case floor4:
                intID = 4;
                break;
            case floor5:
                intID = 5;
                break;
            case floor6:
                intID = 6;
                break;
            case floor7:
                intID = 7;
                break;
            case floor8:
                intID = 8;
                break;
            case floor9:
                intID = 9;
                break;
            case floor10:
                intID = 10;
                break;
            case floor11:
                intID = 11;
                break;
            case floor12:
                intID = 12;
                break;
            case floor13:
                intID = 13;
                break;
            case floor14:
                intID = 14;
                break;
            case floor15:
                intID = 15;
                break;
            case floor16:
                intID = 16;
                break;
            case floor17:
                intID = 17;
                break;
            case floor18:
                intID = 18;
                break;
            case floor19:
                intID = 19;
                break;
            case floor20:
                intID = 20;
                break;
            default:
                intID = 1;
                break;
        }

        return intID;
    }
}
