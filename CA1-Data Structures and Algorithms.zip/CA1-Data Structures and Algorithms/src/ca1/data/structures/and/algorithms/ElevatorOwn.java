/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca1.data.structures.and.algorithms;

import Main.Main;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author angel
 */
public class ElevatorOwn extends Objects {

    private Handler handler;
    private Main main;
    private User user;

    public static int[] insideArray = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    Random r = new Random();

    public static int currentFloor = 0;//starts at the bottom
    int amountOnFloor;

    static int direction = 0;//1 will be when the elevator is moving up and 0 when 
    //moving down

    int state = 0;//0 will be for baseline algorithm of elevator and 1 for self made algorithm

    public static int capacity = 10;//only 10 people are able to get on

    private BufferedImage ele;
    int amountLeft;
    int tempAmount;

    public ElevatorOwn(int x, int y, ID id, Main main, Handler handler, User user) {
        super(x, y, id);

        this.x = x;
        this.y = y;
        this.main = main;
        this.handler = handler;
        this.user = user;

        SpriteSheet ss = new SpriteSheet(Main.elevator);//initialising the image in the constructor
        ele = ss.grabImage(1, 1, 40, 48);
        tempAmount = 0;

    }

    public void tick() {
        y += velY;
        x += velX;

        collision();

        currentFloor = checkFloor(0, this.y);
        if (direction == 0) {
            velY = 1;
        }
        if (direction == 1) {
            velY = -1;
        }

        for (int i = 0; i < Main.array.length; i++) {
            tempAmount += Main.array[i];
        }

        if (tempAmount <= 0) {
            System.out.println("test");
            if (this.y >= 950) {
                velY = 0;
            }
        }

    }

    public void render(Graphics g) {
        g.setColor(Color.red);
        g.drawImage(ele, x, y, null);
        g.drawString(String.valueOf(capacity), x + 13, y + 35);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 40, 48);
    }

    public int checkFloor(int startFloor, int y) {
        int floor = startFloor;
        for (int i = 0; i < 912; i += 48) {
            if (y >= i) {
                floor++;
            } else {
                break;
            }
        }
//        System.out.println("floor = " + floor);
        return floor;
    }

    public int checkUsers(int floorNum) {

        return Main.array[floorNum];
    }

    public void addToInsideArray(int num) {
        int i;
        for (i = 0; i < insideArray.length; i++) {
            if (insideArray[i] == 0) {
                insideArray[i] = num;
                bubbleSort();
                break;
            }
        }
        System.out.println(Arrays.toString(insideArray) + "added");
    }

    public void removeFromInsideArray(int num) {
        int i;
        for (i = 0; i < insideArray.length; i++) {
            if (insideArray[i] == num) {
                insideArray[i] = 0;
            }
        }
        bubbleSort();
        System.out.println(Arrays.toString(insideArray) + "removed");
    }

    private void bubbleSort() {
        int n = insideArray.length;
        int temp = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (insideArray[j - 1] > insideArray[j]) {
                    temp = insideArray[j - 1];
                    insideArray[j - 1] = insideArray[j];
                    insideArray[j] = temp;
                }
            }
        }
    }

    public void addToElevator(int floorNum) {
        if (amountOnFloor > 0) {
            if (capacity <= 10) {
                if (capacity > 0) {
                    for (int j = 0; j < handler.object.size(); j++) {
                        Objects tempObject = handler.object.get(j);

                        if (tempObject.getID() == ID.user) {
//                                System.out.println(Arrays.toString(insideArray));

                            tempObject.state = 1;
                        }
                    }
                }
            }
        }
    }

    private void collision() {
        //collision detection method
        for (int i = 0; i < handler.object.size(); i++) {

            Objects tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.edgeB) {//if the player interacts with a block object

                if (getBounds().intersects(tempObject.getBounds())) {//player cannot go beyond this object
//                    System.out.println(tempObject.getID() + "edgeB");
                    direction = 1;
                }
            }
            if (tempObject.getID() == ID.edgeT) {//if the player interacts with a block object

                if (getBounds().intersects(tempObject.getBounds())) {//player cannot go beyond this object
//                    System.out.println(tempObject.getID() + "edgeT");
                    direction = 0;
                }
            }

            if (tempObject.getID() == ID.floorEdge) {

                if (getBounds().intersects(tempObject.getBounds())) {

                    amountOnFloor = checkUsers(currentFloor);
                    addToElevator(currentFloor);

                }
            }

        }
    }

    @Override
    public int getX() {
        return this.x;
    }

    @Override
    public int getY() {
        return this.y;
    }

    @Override
    public int getVelY() {
        return this.velY;
    }

}
