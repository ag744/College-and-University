package software.development;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 * Class used to create an object which when colliding with the player, ammo is
 * added to the ammo of the player
 *
 * @author Angel
 */
public class Crate extends GameObject {

    private Handler handler;
    private BufferedImage crate_image;

    /**
     * Constructor used to input x and y coordinates of the object, and its ID
     *
     * @param x x-coordinate of crate
     * @param y y-coordinate of crate
     * @param id id of crate
     * @param handler
     */
    public Crate(int x, int y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

//        SpriteSheet ss = new SpriteSheet(crate_image);
//        
//        ss.grabImage(1, 1, 16, 16);
    }

    /**
     * no functionality
     */
    public void tick() {

    }

    /**
     * Renders the object as a cyan rectangle which is 16 by 16 pixels of size
     *
     * @param g
     */
    public void render(Graphics g) {
        g.setColor(Color.cyan);
        g.fillRect((int) x, (int) y, 16, 16);
    }

    /**
     * creates a hit-box which is a rectangle of size 16x16
     *
     * @return
     */
    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 16, 16);
    }

}
