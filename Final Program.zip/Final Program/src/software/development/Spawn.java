package software.development;

import software.development.Game.STATE;
import java.util.Random;

/**
 * Class used to spawn new players, enemies, smart enemies and crates
 *
 * @author gel17835534
 */
public class Spawn {

    private Game game;
    private Handler handler;
    private LevelScore ls;
    static Player player;
    private Camera camera;
    private SpawnA spawna = new SpawnA();
    static Saver saver;
    public static Login user;
    public Menus menu;

    /**
     * used to determine where the player is in terms of rooms
     */
    public static int currentRoom;

    public Spawn(Handler handler, Game game, LevelScore ls, Player player, Spawn spawn, Camera camera, SpawnA spawna) {
        this.game = game;
        this.handler = handler;
        this.ls = ls;
        this.player = player;
        this.camera = camera;

    }

    /**
     * no functionality
     */
    public void tick() {

    }

    /**
     * spawns a new player in the previous room when player collides with left
     * portal
     *
     * @param player
     */
    public void spawnLeft(GameObject player) {
        handler.removeObject(player);

        if (currentRoom == 1) {//room2 to room1
            handler.addObject(new Player(1960, 795, ID.Player, handler, game, this, spawna));//spawns player back in first room
            currentRoom = 0;
            System.out.println(currentRoom);
            return;
            //correct
        }
        if (currentRoom == 2) {//room3 to room2
            handler.addObject(new Player(4000, 795, ID.Player, handler, game, this, spawna));
            currentRoom = 1;
            System.out.println(currentRoom);
            return;
            //correct
        }
        if (currentRoom == 3) {//room4 to room3
            handler.addObject(new Player(1960, 1950, ID.Player, handler, game, this, spawna));
            currentRoom = 2;
            System.out.println(currentRoom);
            return;
            //correct
        }
        if (currentRoom == 4) {//room5 to room4
            handler.addObject(new Player(4000, 1950, ID.Player, handler, game, this, spawna));
            currentRoom = 3;
            System.out.println(currentRoom);
            return;
            //correct
        }
        if (currentRoom == 5) {//room6 to room5
            handler.addObject(new Player(1960, 3000, ID.Player, handler, game, this, spawna));
            currentRoom = 4;
            System.out.println(currentRoom);
            return;
            //correct
        }
//        decRoom();
    }

    /**
     * spawns a new player in the previous room when player collides with right
     * portal
     *
     * @param player
     */
    public void spawnRight(GameObject player) {
        System.out.println("debug currentRoom: " + currentRoom);
        handler.removeObject(player);

        if (currentRoom == 5) {//room6
//            handler.object.clear();
            handler.removeAll(handler.object);
            game.gameState = STATE.end;
            menu.tick();
            currentRoom = 0;
            System.out.println(currentRoom);
            return;
        }

        if (currentRoom == 4) {//room5 to room6
            handler.addObject(new Player(3100, 3100, ID.Player, handler, game, this, spawna));// spawns player in sixth room
            spawnSmart(6);
            spawnCrates(10);
            Enemy.enemyCounter = 6;
            currentRoom = 5;
            System.out.println(currentRoom);
            return;
            //correct
        }

        if (currentRoom == 3) {//room4 to room5
            handler.addObject(new Player(1050, 3100, ID.Player, handler, game, this, spawna));//spawn player in fifth room
            spawnEnemies(3);
            spawnSmart(3);
            spawnCrates(5);
            Enemy.enemyCounter = 6;
            currentRoom = 4;
            System.out.println(currentRoom);
            return;
            //correct
        }

        if (currentRoom == 2) {//room3 to room4
            handler.addObject(new Player(3100, 1950, ID.Player, handler, game, this, spawna));//spawns player in fourth room
            spawnEnemies(5);
            spawnSmart(1);
            spawnCrates(5);
            Enemy.enemyCounter = 6;
            currentRoom = 3;
            System.out.println(currentRoom);
            return;
            //correct
        }

        if (currentRoom == 1) {//room2 to room3
            handler.addObject(new Player(1050, 1950, ID.Player, handler, game, this, spawna));//spawns player in third room
            spawnEnemies(10);
            spawnCrates(4);
            Enemy.enemyCounter = 10;
            currentRoom = 2;
            System.out.println(currentRoom);
            return;
            //correct
        }

        if (currentRoom == 0) {//room1 to room2
            handler.addObject(new Player(3100, 795, ID.Player, handler, game, this, spawna));//spawns player in second room
            spawnEnemies(5);
            spawnCrates(3);
            Enemy.enemyCounter = 5;
            currentRoom = 1;
            System.out.println(currentRoom);

            //correct
        }

//        System.out.println("debug currentRoom: " + currentRoom);
    }

    /**
     * spawns new enemies every time the player goes to the next room
     *
     * @param amount amount of enemies to be spawned
     */
    public void spawnEnemies(int amount) {

        Random r = new Random();

        if (currentRoom == 0) {//room1

            for (int i = 0; i < amount; i++) {
                handler.addObject(new Enemy(r.nextInt(4065 - 3100) + 3100, r.nextInt(1080 - 610) + 610, ID.Enemy, handler));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 1) {//room2
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Enemy(r.nextInt(2015 - 1060) + 1060, r.nextInt(2270 - 1760) + 1760, ID.Enemy, handler));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 2) {//room3
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Enemy(r.nextInt(4060 - 3105) + 3105, r.nextInt(2270 - 1760) + 1760, ID.Enemy, handler));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 3) {//room4
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Enemy(r.nextInt(2015 - 1060) + 1060, r.nextInt(3420 - 2915) + 2915, ID.Enemy, handler));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 4) {//room5
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Enemy(r.nextInt(4060 - 3105) + 3105, r.nextInt(3420 - 2915) + 2915, ID.Enemy, handler));
//                Enemy.enemyCounter++;
            }
        }
    }

    /**
     * spawns new crates of ammo every time the player goes to the next room
     *
     * @param amount
     */
    public void spawnCrates(int amount) {

        Random r = new Random();

        if (currentRoom == 0) {

            for (int i = 0; i < amount; i++) {
                handler.addObject(new Crate(r.nextInt(3800 - 3300) + 3300, r.nextInt(800 - 700) + 700, ID.Crate, handler));

            }
        }
        if (currentRoom == 1) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Crate(r.nextInt(1800 - 1200) + 1200, r.nextInt(2000 - 1800) + 1800, ID.Crate, handler));

            }
        }
        if (currentRoom == 2) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Crate(r.nextInt(3800 - 3300) + 3300, r.nextInt(2000 - 1800) + 1800, ID.Crate, handler));

            }
        }
        if (currentRoom == 3) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Crate(r.nextInt(1800 - 1200) + 1200, r.nextInt(3200 - 3100) + 3100, ID.Crate, handler));

            }
        }
        if (currentRoom == 4) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new Crate(r.nextInt(3800 - 3300) + 3300, r.nextInt(3200 - 3100) + 3100, ID.Crate, handler));

            }
        }
    }

    /**
     * spawns new smart enemies every time the player goes to the next room
     *
     * @param amount
     */
    public void spawnSmart(int amount) {

        Random r = new Random();

        if (currentRoom == 0) {

            for (int i = 0; i < amount; i++) {
                handler.addObject(new SmartEnemy((r.nextInt(4200 - 2800) + 2800), (r.nextInt(1200 - 500) + 500), ID.SmartEnemy, handler, player));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 1) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new SmartEnemy((r.nextInt(2200 - 900) + 900), (r.nextInt(2400 - 1600) + 1600), ID.SmartEnemy, handler, player));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 2) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new SmartEnemy((r.nextInt(4200 - 3000) + 3000), (r.nextInt(2400 - 1600) + 1600), ID.SmartEnemy, handler, player));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 3) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new SmartEnemy((r.nextInt(2200 - 900) + 900), (r.nextInt(3600 - 2800) + 2800), ID.SmartEnemy, handler, player));
//                Enemy.enemyCounter++;
            }
        }
        if (currentRoom == 4) {
            for (int i = 0; i < amount; i++) {
                handler.addObject(new SmartEnemy((r.nextInt(4200 - 3000) + 3000), (r.nextInt(3600 - 2800) + 2800), ID.SmartEnemy, handler, player));
//                Enemy.enemyCounter++;
            }
        }
    }

    /**
     * increments the currentRoom variable
     *
     * @return
     */
    public int incRoom() {
        currentRoom++;
        return currentRoom;
    }

    /**
     * decrements the currentRoom variable
     *
     * @return
     */
    public int decRoom() {
        currentRoom--;
        return currentRoom;
    }

}
