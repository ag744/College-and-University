package software.development;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

/*
 * Main class
 * Contains main method, creates the window frame and renders all of the graphics
 */
/**
 *
 * @author Angel Gelemerov
 */
public class Game extends Canvas implements Runnable {
    //all images used are in the 'res' folder (for the floor in the prototype I have used an image I previously made so it has some extra things)

    private boolean running = false;//boolean used to tell when the program is running the game loop and when it is not

    //declaration of all other classes as objects for further use
    Thread thread;
    private Handler handler;
    private BufferedImage level;
    private Camera camera;
    private SpriteSheet ss;
    private BufferedImage floor;
    private Player player;
    private Menus menu;
    private LevelScore ls;
    private Spawn spawn;
    private MouseInput mouse;
    private Highscore hs;
    private Login login;
    private Enemy enemy;
    private Saver saver = new Saver();
    private Loader loader;
    private SpawnA spawna;

    /**
     * Width of the frame for the game
     */
    public static final int WIDTH = 1000;

    /**
     * Height of the frame for the game
     */
    public static final int HEIGHT = 563;

    /**
     * used to tell when the game is paused
     */
    public static boolean paused = false;

    /**
     * Image used for background of room Edit: this was previously used to
     * render a background image for rooms, but as it proved highly inefficient,
     * i decided to remove it and therefore disabled the image as well
     */
//    private BufferedImage sprite_sheet;
    /**
     * Image used for the graphics of the player model
     */
    public static BufferedImage player_male2;

    /**
     * Image used for the graphics of a portal
     */
    public static BufferedImage portal;

    /**
     * image used for the layout of the rooms
     */
    public BufferedImage allRooms;

    /**
     * Image used for the graphic of the edge of room
     */
    public static BufferedImage tiles;

    private BufferedImage background;

    /**
     *
     */
    public BufferedImage blank;

    /**
     * Enumeration class used as a state machine to make it easier to navigate
     * between all of the states of the game
     */
    public enum STATE {

        /**
         * when the game is being played
         */
        game(),
        /**
         * when in the Main Menu section
         */
        menu(),
        /**
         * When the player has died
         */
        death(),
        /**
         * When the player has finished/won the game
         */
        end(),
        /**
         * when the player uses the shop
         */
        shop(),
        /**
         * when the player is in the help menu
         */
        help(),
        /**
         *
         */
        highscores(),
        /**
         *
         */
        load(),
        /**
         *
         */
        save();
    }

    /**
     * initial state of the game state
     */
    public STATE gameState = STATE.menu;//initial state of the program

    /**
     * constructor method containing all of the loading of images, listeners and
     * the window
     */
    public Game() {
        BufferedImageLoader loader = new BufferedImageLoader();

        handler = new Handler();
        ls = new LevelScore(this, spawn, login);
        camera = new Camera(0, 0);
        menu = new Menus(this, handler, ls, spawn, camera, hs, enemy, saver, player);
        spawn = new Spawn(handler, this, ls, player, spawn, camera, spawna);
        spawna = new SpawnA();

//        sprite_sheet = loader.loadImage("/sprite_sheet.png");
        player_male2 = loader.loadImage("/player_male2.png");
        portal = loader.loadImage("/portal.png");
        allRooms = loader.loadImage("/allLvl2.png");
        blank = loader.loadImage("/blank.png");
        tiles = loader.loadImage("/tiles.png");

//        ss = new SpriteSheet(sprite_sheet);
//        floor = ss.grabImage(3, 3, 32, 32);
        //initialisation of action listeners
        this.addKeyListener(new KeyInput(handler, this, spawn));//addition of key and mouse listeners using a self-made class to handle the events caused by the mouse and keyboard
        this.addMouseListener(new Menus(this, handler, ls, spawn, camera, hs, enemy, saver, player));
        this.addMouseListener(new MouseInput(handler, camera, this, spawn));//events caused by the mouse

        new Window(WIDTH, HEIGHT, "Game", this);//makes the frame with parameters required and title "Game"

        start();

    }

    //start up of thread
    private void start() {
        running = true;//when running is true, the run() method is going to be executed
        thread = new Thread(this);
        thread.start();
    }

    //end of thread
    private void stop() {
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    //game loop method which is running the program constantly
    public void run() {//updates 60 times a second

        //every comment that has a '//debug' on it is used for the monitoring of frames and ticks of the game while it is running 
        //does not contribute to the functionality of the game itselfs
        this.requestFocus();//requests focus of window automatically
        long lastTime = System.nanoTime();//takes the current time from the system clock niin nano seconds
        final double amountOfTicks = 60; //60 ticks
        double ns = 1000000000 / amountOfTicks;//1 billion is 1 second in nanoseconds
        double delta = 0;//variable used to catch up on time
        long timer = System.currentTimeMillis();//takes current time of system on milliseconds

        int updates = 0;//ticks the game is//debug
        int frames = 0;//frames per second the game is running at//debug

        while (running) {//game loop
            long now = System.nanoTime();//takes the current system clock time in nanoseconds
            delta += (now - lastTime) / ns;//uses delta to see the difference and catch up
            lastTime = now;//setting last time to equal the time now
            if (delta >= 1) {
                tick();
                updates++;//debug
                delta--;
            }
            render();
            frames++;//debug

            //debug
            if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;//adds 1000 so that it runs this code every second
                //(1000 milliseconds are 1 second)
                System.out.println("Frames " + frames + "  |  Ticks " + updates);//prints off FPS in the 

                //console window
                frames = 0;//resets frames and updates so that  
                updates = 0;//they don't add up with the previous values
            }
        }
        stop();

    }

    /**
     * method used to update listed objects and their classes while the game is
     * running
     */
    public void tick() {
        if (paused == false) {
            if (gameState == STATE.game) {
                for (int i = 0; i < handler.object.size(); i++) {//loops through all of the objects in the LinkedList
                    if (handler.object.get(i).getID() == ID.Player) {
                        camera.tick(handler.object.get(i));
                    }
                }
                handler.tick();
                ls.tick();
                spawn.tick();
                menu.tick();

                if (LevelScore.hp <= 0) {
                    gameState = STATE.death;//if the health(hp - health points) of the player reaches 0, the player is removed and the gamestate is changed
                    handler.object.clear();
                }
            }
        }
        if (gameState == STATE.menu) {
            menu.tick();
        }
    }

    /**
     * Method used to render all of the graphics and buffer next frames
     */
    public void render() {
        BufferStrategy bs = this.getBufferStrategy();

        if (bs == null) {
            this.createBufferStrategy(3);//preloading next frames, has 2 frames in queue ready to show(buffers the next two frames)
            return;
        }

        Graphics g = bs.getDrawGraphics();

        Graphics2D g2d = (Graphics2D) g;

        g.setColor(Color.black);//sets the colour to black and fills the window in the specified colour
        g.fillRect(0, 0, WIDTH, HEIGHT);
//        g.drawImage(background, 0, 0, this);

//            System.out.println("debug gameState");
        g2d.translate(-camera.getX(), -camera.getY());//moves camera according to the players movements on-screen (up and left)
        //translates the player's position and moves the window relative to it so that the player is always in the middle
        //(unless at the edge of the window)

//        if (gameState == STATE.game) {
//            for (int x = 0; x < 30 * 100; x += 164) {//30 is timesed by 72 because you need 72 tiles to fill out the screen properly (same goes for y value)
//                for (int y = 0; y < 30 * 100; y += 94) {
//                    g.drawImage(floor, x, y, null);
//
//                }
//            }
//        }
// This was initially used to draw many of the same image as the background of the game but 
//as it was causing major frame issues, I decided to exclude it from the game
        handler.render(g);

        g2d.translate(camera.getX(), camera.getY());//moves camera according to the players movements on-screen (down and right)

        ls.render(g);//used to render in the health and score tab at the top left of the screen

        if (gameState == STATE.death
                || gameState == STATE.menu
                || gameState == STATE.help
                || gameState == STATE.end
                || gameState == STATE.highscores
                || gameState == STATE.load) {
            menu.render(g);
            handler.render(g);
        }

        //draws a 'Paused' message if the user pauses the game (button press)
        if (paused == true) {
            menu.render(g);
        }

        g.dispose();//closes Graphics object
        bs.show();//renders the buffer

    }

    /**
     * procedure which will load the image specified in parameters
     *
     * @param image image will take only blue(Player), green(Enemy),
     * cyan(Crate), magenta(Portal1) and magenta with 1 point in green RGB value
     * (Portal2)
     */
    public void loadLevel(BufferedImage image) {
        int width = image.getWidth();//width and height of the image
        int height = image.getHeight();

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {

                int pixel = image.getRGB(x, y);
                //
                int red = (pixel >> 16) & 0xff;//shifts pixel 16 to the right  
                int green = (pixel >> 8) & 0xff;//shifts pixel 8 to the right
                int blue = (pixel) & 0xff;

                if (red == 255 && green == 0 && blue == 0) {
                    handler.addObject(new Block(x * 32, y * 32, ID.Block));//spawns a Block object when there is a red pixel in the loaded image
                }
                if (red == 0 && green == 0 && blue == 255) {
                    handler.addObject(new Player(x * 32, y * 32, ID.Player, handler, this, spawn, spawna));//spawns a Player object when there is a blue pixel in the loaded image
                }
                if (red == 0 && green == 255 && blue == 0) {
                    handler.addObject(new Enemy(x * 32, y * 32, ID.Enemy, handler));//spawns an Enemy object when there is a green pixel in the loaded image
//                    Enemy.enemyCounter++;
                }
                if (red == 0 && green == 255 && blue == 255) {
                    handler.addObject(new Crate(x * 32, y * 32, ID.Crate, handler));//spawns a Crate object when there is a cyan pixel in the loaded image
                }
                if (red == 255 && green == 0 && blue == 255) {
                    handler.addObject(new Portal(x * 32, y * 32, ID.Portal1));//spawns a Portal object which will teleport the player to the next room
                }
                if (red == 255 && green == 1 && blue == 255) {
                    handler.addObject(new Portal(x * 32, y * 32, ID.Portal2));//spawns a Portal object which will teleport the player to the previous room
                }

                if (red == 255 && green == 100 && blue == 0) {
                    handler.addObject(new DoorBlock(x * 32, y * 32, ID.DoorBlock));//spawns a Portal object which will teleport the player to the previous room
                }

                if (red == 255 && green == 255 && blue == 0) {
                    handler.addObject(new Border(x * 32, y * 32, ID.Border));
                }
            }
        }
//        System.out.println("debug: load");
    }

    /**
     * main method used to start the program
     *
     * @param args
     */
    public static void main(String args[]) {
//        new Register().setVisible(true);
        new Login().setVisible(true);
    }

}
