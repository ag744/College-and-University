package software.development;

import java.awt.Graphics;
import java.util.LinkedList;

/**
 * Handler class used to execute the tick() and render() methods of all classes
 * extending the LinkedList
 *
 * @author Angel
 */
public class Handler {

    //LinkedList data structure which will store all of the objects made with the use of the GameObject class
    LinkedList<GameObject> object = new LinkedList<>();

    //booleans which will indicate the direction in which the player is moving
    private boolean up = false;
    private boolean down = false;
    private boolean left = false;
    private boolean right = false;

    /**
     * used to update every object
     */
    public void tick() {

        for (int i = 0; i < object.size(); i++) {//loops through all of the objects
            GameObject tempObject = object.get(i);

            tempObject.tick();//runs the object's tick() method
        }

    }

    /**
     * used to render every object
     *
     * @param g
     */
    public void render(Graphics g) {

        for (int i = 0; i < object.size(); i++) {//loops through all of the objects
            GameObject tempObject = object.get(i);

            tempObject.render(g);//runs the object's render() method
        }
    }

    /**
     * adding an object
     *
     * @param Object
     */
    public void addObject(GameObject Object) {
        object.add(Object);

    }

    /**
     * removing an object
     *
     * @param Object
     */
    public void removeObject(GameObject Object) {
        object.remove(Object);
    }

    /**
     * removing all objects in the linked list
     *
     * @param object
     */
    public void removeAll(LinkedList<GameObject> object) {
        object.clear();
    }

    /*
    getters and setters for booleans indicating the movement of the player
     */
    public boolean isUp() {
        return up;
    }

    public void setUp(boolean up) {
        this.up = up;
    }

    public boolean isDown() {
        return down;
    }

    public void setDown(boolean down) {
        this.down = down;
    }

    public boolean isLeft() {
        return left;
    }

    public void setLeft(boolean left) {
        this.left = left;
    }

    public boolean isRight() {
        return right;
    }

    public void setRight(boolean right) {
        this.right = right;
    }

}
