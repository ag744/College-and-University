package software.development;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

/**
 *
 * @author angel
 */
public class SmartEnemy extends GameObject {

    private Handler handler;

    int hp = 200;

    /**
     *
     */
    public static Player player;
    //private BufferedImage enemy_image;

    /**
     *
     * @param x
     * @param y
     * @param id
     * @param handler
     * @param player
     */
    public SmartEnemy(float x, float y, ID id, Handler handler, Player player) {
        super(x, y, id);

        this.handler = handler;
    }

    public void tick() {
        x += velX;
        y += velY;

        for (int i = 0; i < handler.object.size(); i++) {
            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Bullet) {
                if (getBounds2D(getBounds()).intersects(tempObject.getBounds())) {
                    hp = hp - 10;
                    System.out.println("hp: " + hp);
                    handler.removeObject(tempObject);
                }
            }
        }

        if (hp <= 0) {
            handler.removeObject(this);
            LevelScore.score += 2000;
            Enemy.enemyCounter--;
        }

        float diffX = (x - player.getX() - 8);
        float diffY = (y - player.getY() - 8);

        float distance = (float) Math.sqrt(((x - player.getX()) * (x - player.getX())) + ((y - player.getY()) * (y - player.getY())));

        velX = (float) (-1 / distance) * diffX * 2;
        velY = (float) (-1 / distance) * diffY * 2;

    }

    public void render(Graphics g) {

        //g.drawImage(enemy_image, (int)x, (int)y, null);
        g.setColor(Color.red);//setting of enemy colour as green
        g.fillRect((int) x, (int) y, 32, 32);//setting of enemy size of object to 16x16 pixels
    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 32, 32);//creation of hitboxes using Rectangle
    }

    /**
     *
     * @param rect
     * @return
     */
    public Rectangle2D getBounds2D(Rectangle rect) {
        return rect.getBounds2D();
    }
}
