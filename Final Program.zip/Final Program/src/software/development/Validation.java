package software.development;

/**
 *
 * @author gel17835534
 */
public class Validation {

    /**
     * length check for numbers
     *
     * @param reqLength maximum length
     * @param number actual number input
     * @return returns true if the number is the length specified
     */
    public static boolean lengthC(int reqLength, int number) {
        if (number == reqLength) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * presence check
     *
     * @param present actual field to be checked
     * @return returns true if there is something written in the field
     */
    public static boolean presenceC(String present) {
        if (present != null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * range check
     *
     * @param value value to be checked
     * @param min minimum limit
     * @param max maximum limit
     * @return returns true if value is within the limits specified
     */
    public static boolean rangeC(int value, int min, int max) {
        if (value <= max && value >= min) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * type check for integers
     *
     * @param num integer to be checked(must be cast as String)
     * @return returns true if passed String is of an integer type
     */
    public static boolean typeCint(String num) {

        try {
            Integer.parseInt(num);
            return true;
        } catch (Exception e) {
            return false;
        }

    }

    /**
     * type check for String
     *
     * @param str actual string to be checked
     * @return returns true if the string passed through parameters is of a
     * String type
     */
    public static boolean typeCstr(String str) {
        if (str.equals(String.valueOf(str))) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * type check for boolean values
     *
     * @param boo actual boolean to be checked
     * @return returns true if passed value is boolean(/ if passed value is
     * equal to either true or false)
     */
    public static boolean typeCboo(String boo) {
        if (boo.equals("true") || boo.equals("false")) {
            return true;
        } else {
            return false;
        }
    }

}
