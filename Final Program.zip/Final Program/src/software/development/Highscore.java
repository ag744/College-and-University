package software.development;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;

/**
 *
 * @author angel
 */
public class Highscore {

    int fileRows = 20;
//    public static Sorting s = new Sorting();

    public Highscore() {
    }

    public void update(int score, String username) {
        try {
            
            int j = 0;
            
            FileWriter writer = new FileWriter("highscores.txt", true);
            writer.write(username + ",");
            writer.write(score + "\n");
            writer.close();

            File file = new File("highscores.txt");
            file.createNewFile();

            BufferedReader reader = new BufferedReader(new FileReader("highscores.txt"));

            String[][] array = new String[fileRows][2];
            String[] temp;
            String read;

            int row = 0;

            System.out.println("saved to highscores");

            System.out.println("before populating: " + Arrays.deepToString(array));

            while ((read = reader.readLine()) != null) {
                j++;
                temp = read.split(",");

                System.out.println(read);
                System.out.println("rows: " + j);

                for (int i = 0; i < 2; i++) {
                    array[row][i] = temp[i];
                }
                row++;
            }

            System.out.println("after populating: " + Arrays.deepToString(array));

            new Sorting(array);

            System.out.println("after sorting: " + Arrays.deepToString(array));

            reader.close();
//            writer.close();

            writeIntoTemp(array);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void writeIntoTemp(String[][] array) throws Exception {

        File temp = new File("temp.txt");
        File file = new File("highscores.txt");

        temp.createNewFile();

        FileWriter writer = new FileWriter("temp.txt");
//        BufferedWriter buffer = new BufferedWriter(writer);

        for (int i = 0; i < fileRows; i++) {

            if (array[i][0] != null && array[i][1] != null) {

                writer.write(array[i][0] + ",");
                writer.write(array[i][1] + "\n");
            }
        }

        writer.close();

//        temp.renameTo(file);
//        file.delete();
    }

    /**
     * this was a previous attempt at making the high score table work i decided
     * to switch approach and do it another way
     */
//    /**
//     * writes to highscores.txt for each user and then their score after
//     *
//     * @param newScore
//     */
//    public void fixScores(int newScore) {
//        try {
//            File f = new File("highscores.txt");
//            FileWriter writer = new FileWriter("highscores.txt", true);
//            BufferedWriter buffer = new BufferedWriter(writer);
//
//            Scanner s = new Scanner(f);
//
//            List<String> list = new ArrayList<>();
//
//            boolean done = false;
//
//            String username = Login.user;
//
//            while (s.hasNextLine()) {
//                list.add(s.nextLine());
//            }
//
//            for (String st : list) {
//                String[] sa = st.split(",");
//                if (sa[0].equals(username)) {
////                    list = update2(newScore, username, list);
//                    done = true;
//                }
//            }
//
//            if (!done) {
//                String[][] array = new String[list.size()][2];
//                int i = 0;
//                for (String string : list) {
//                    array[i] = string.split(",");
//                    i++;
//                }
//                list = addNew(newScore, username, array);
//            }
//
//            for (String string : list) {
//                buffer.write(string + System.lineSeparator());
//            }
//            buffer.close();
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
//    /**
//     * Change the value of the highest score of the player if the player is
//     * already in the highscore table.
//     *
//     * @param username the name
//     * @param newScore the new score
//     * @param list the existing highscore table
//     * @return
//     */
//    public List<String> update(String username, int newScore, List<String> list) {
//        List<String> temp = new ArrayList<>();
//        String[][] array = new String[list.size()][2];
//        int i = 0;
//        for (String str : list) {
//            String[] sa = str.split(",");
//            array[i] = sa;
//            i++;
//        }
//        for (i = 0; i < array.length; i++) {
//            if (array[i][0].equals(username)) {
//                if (Integer.parseInt(array[i][1]) < newScore) {
//                    array[i][1] = "" + newScore;
//                    break;
//                }
//            }
//        }
//        while (i != 0 && (Integer.parseInt(array[i - 1][1]) < newScore)) {
//            String[] temp2 = new String[2];
//            System.arraycopy(array[i - 1], 0, temp2, 0, temp2.length);
//            array[i - 1][0] = username;
//            array[i - 1][1] = String.valueOf(newScore);
//            array[i] = temp2;
//            i--;
//        }
//        for (i = 0; i < array.length; i++) {
//            temp.add(array[i][0] + "," + array[i][1]);
//        }
//        return temp;
//    }
//    /**
//     * Add new user and his highscore in the right place in the highscores
//     * table.
//     *
//     * @param score the score of the new user
//     * @param username the new user
//     * @param input the existing highscore table
//     * @return returns the ArrayList with the username and score of the current
//     * user
//     */
//    public List<String> addNew(int score, String username, String[][] input) {
//        List<String> list = new ArrayList<>();//actual list to be added to
//        String[][] temp = new String[input.length + 1][2];//temporary list which is edited
//        int i = 0;//amount of rows
//        boolean done = false;
//        if (input.length < 1) {//if the file is empty write the current user's highest score
//            temp[0][0] = username;
//            temp[0][1] = "" + score;
//            done = true;
//        } else {
//            for (i = 0; i < input.length; i++) {
//                if (Integer.parseInt(input[i][1]) < score) {
//                    int j;//amount of rows
//                    for (j = 0; j < i; j++) {
//                        temp[j][0] = input[j][0];
//                        temp[j][1] = input[j][1];
//                    }
//                    temp[j][0] = username;
//                    temp[j][1] = "" + score;
//                    int k;
//                    for (k = j; k < temp.length; k++) {
//                        temp[k][0] = input[k - 1][0];
//                        temp[k][1] = input[k - 1][1];
//                    }
//                } else {
//                    if (i < input.length) {
//                        temp[i][0] = input[i][0];
//                        temp[i][1] = input[i][1];
//                    }
//                }
//            }
//        }
//        if (temp[i][0] == null && !done) {
//            temp[i][0] = username;
//            temp[i][1] = "" + score;
//        }
//        for (i = 0; i < temp.length; i++) {
//            list.add(temp[i][0] + "," + temp[i][1]);
//        }
//        return list;
//    }
    
}
