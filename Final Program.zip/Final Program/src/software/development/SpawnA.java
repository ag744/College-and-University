package software.development;

import java.awt.Rectangle;

/**
 * Class used to set bounds which will tell the spawning mechanisms of the game
 * where they are able to spawn object
 *
 * @author angel
 */
public class SpawnA {

    Rectangle rect2;
    Rectangle rect3;
    Rectangle rect4;
    Rectangle rect5;
    Rectangle rect6;

    /**
     * initialises the Rectangle objects and gives the a value
     */
    public SpawnA() {
        rect2 = new Rectangle(3100, 610, 965, 470);
        rect3 = new Rectangle(1060, 1760, 955, 510);
        rect4 = new Rectangle(3105, 1760, 955, 510);
        rect5 = new Rectangle(1060, 2915, 955, 505);
        rect6 = new Rectangle(3300, 2915, 785, 505);
    }

    /**
     * the spawning area changes with each room
     *
     * @return returns the current rooms spawning area
     */
    public Rectangle getBounds() {

        if (Spawn.currentRoom == 2) {
            return new Rectangle(3100, 610, 965, 470);
        }
        if (Spawn.currentRoom == 3) {
            return new Rectangle(1060, 1760, 955, 510);
        }
        if (Spawn.currentRoom == 4) {
            return new Rectangle(3105, 1760, 955, 510);
        }
        if (Spawn.currentRoom == 5) {
            return new Rectangle(1060, 2915, 955, 505);
        } else {
            return new Rectangle(3105, 2915, 955, 505);
        }
    }

}
