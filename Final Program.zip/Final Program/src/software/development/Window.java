package software.development;

import java.awt.Dimension;
import javax.swing.JFrame;

/**
 * Class used to make the initial frame of the game
 *
 * @author Angel
 */
public class Window {

    /**
     * Constructor used to create a new JFrame
     *
     * @param width width of the frame
     * @param height height of the frame
     * @param title title of the frame
     * @param game main class object (Game)
     */
    public Window(int width, int height, String title, Game game) {

        JFrame frame = new JFrame(title);

        frame.setPreferredSize(new Dimension(width, height));//sets the size
        frame.setMaximumSize(new Dimension(width, height));
        frame.setMinimumSize(new Dimension(width, height));

        frame.add(game);
        frame.setResizable(false);//cannot resize window
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);//centres the window
        frame.setVisible(true);//displays the frame
    }

}
