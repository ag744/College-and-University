package software.development;

import java.util.Arrays;

/**
 * Class used to sort, ended up not using it. These are just previously written
 * methods prior to this project
 *
 * @author gel17835534
 */
public class Sorting {

    static public boolean sorted = false;
    static final int[] ARRAYU = {31, 2, 5, 64, 37, 58, 53, 41, 98, 50};

//    /**
//     *
//     * @param array
//     */
//    public String[][] sorting(String[][] array) {
//        bubbleSortDescending2D2(array, 1);
//        return array;
//    }
    public Sorting(String[][] array) {
        array = bubble(array, 1);
    }

    public Sorting() {
        bubbleSortDescending(ARRAYU);
    }

    /**
     *
     * @param array
     */
    public void bubbleSortDescending(int[] array) {
        int n = array.length;

        boolean swapped = false;

        for (int i = 0; i < n - 1; i++) {

            int key = array[i + 1];
            int subKey = array[i];

            if (key > subKey) {

                int tempNum = subKey;
                array[i + 1] = tempNum;
                array[i] = key;

                swapped = true;

            }
        }
        System.out.println("" + array[0] + " " + array[1] + " " + array[2] + " " + array[3]
                + " " + array[4] + " " + array[5] + " " + array[6]
                + " " + array[7] + " " + array[8] + " " + array[9]);
        if (swapped) {
            bubbleSortDescending(array);
        }
    }

    /**
     *
     * @param array
     * @param column
     * @return
     */
    public String[][] bubbleSortDescending2D2(String[][] array, int column) {

        boolean sorted = false;
        boolean swapped = false;

        while (sorted == false) {
            try {
                String temp = " ";
                for (int i = 0; i < array.length - 1; i++) {

//                    System.out.println("column 1 = " + array[i][column]);
//                    System.out.println("column 2 = " + array[i + 1][column]);
                    if (array[i + 1][column] != null) {
                        if (array[i][column].compareTo(array[i + 1][column]) < 0) {//if previous is smaller than next element then swap

//                    if (Integer.parseInt(array[i][column]) < Integer.parseInt(array[i+1][column]))    {
//                            System.out.println("column 1 < column 2");
                            temp = array[i][column];//swapping of score
                            array[i][column] = array[i + 1][column];
                            array[i + 1][column] = temp;

                            temp = array[i][0];//swapping of names
                            array[i][0] = array[i + 1][0];
                            array[i + 1][0] = temp;

                            swapped = true;

                            System.out.println(Arrays.deepToString(array));

                            bubbleSortDescending2D2(array, column);

                        }
                    } else {
                        sorted = true;
                        break;

                    }
                }
            } catch (Exception e) {
                sorted = false;
            }

        }
        return array;
    }

    /**
     * Sorts 2D String array by address passed numerically!!!
     *
     * @param toSort
     * @param addressToSortBy
     * @return Returns sorted 2D String array in ascending order
     */
    public String[][] bubble(String[][] toSort, int addressToSortBy) {
        String[] temp = new String[toSort[0].length];
        boolean changeMade;

        do {
            changeMade = false;
            for (int i = 0; i < toSort.length - 1; i++) {

                if (toSort[i + 1][addressToSortBy] != null) {

                    if (Integer.parseInt(toSort[i][addressToSortBy]) < Integer.parseInt(toSort[i + 1][addressToSortBy])) {

                        temp = toSort[i + 1];
                        toSort[i + 1] = toSort[i];
                        toSort[i] = temp;
                        changeMade = true;
                    }
                }
            }
        } while (changeMade);

        return toSort;

    }

    /**
     *
     * @param array
     */
    public void sortDescending(int[] array) {
        int n = array.length;
        boolean swapped = false;
        for (int i = 0; i < n - 1; i++) {
            int key = array[i + 1];
            int subKey = array[i];
            if (key > subKey) {
                int tempNum = subKey;
                subKey = key;
                array[i + 1] = tempNum;
                array[i] = key;
                swapped = true;
            }
        }
        System.out.println("" + array[0] + " " + array[1] + " " + array[2] + " " + array[3]
                + " " + array[4] + " " + array[5] + " " + array[6]
                + " " + array[7] + " " + array[8] + " " + array[9]);
        if (swapped) {
            bubbleSortDescending(array);
        }
    }

    /**
     *
     * @param array
     */
    public void bubbleSortAscending(int[] array) {
        int n = array.length;
        boolean swapped = false;
        for (int i = n - 1; i > 0; i--) {
            int key = array[i];
            int subKey = array[i - 1];
            if (key > subKey) {
                int tempNum = subKey;
                subKey = key;
                array[i] = tempNum;
                array[i - 1] = key;
                swapped = true;
            }

            System.out.println("" + array[0] + " " + array[1] + " " + array[2] + " " + array[3]
                    + " " + array[4] + " " + array[5] + " " + array[6]
                    + " " + array[7] + " " + array[8] + " " + array[9]);
            if (swapped) {
                bubbleSortAscending(array);
            }
        }
    }

    /**
     *
     * @param first
     * @param last
     * @param array
     */
    public void quickSort(int first, int last, int[] array) {
        int left = first;
        int right = last;
        int pivot = array[(left + right) / 2];
        while (left <= right) {
            while (array[left] < pivot) {
                left++;
            }
            while (array[right] > pivot) {
                right--;
            }
            if (left <= right) {
                int tempNum = array[left];
                array[left] = array[right];
                array[right] = tempNum;
                left++;
                right--;
            }
        }
        if (first < right) {
            quickSort(first, right, array);
        }
        if (left < last) {
            quickSort(left, last, array);
        }
    }

    /**
     *
     * @param first
     * @param last
     * @param column
     * @param array //
     */
//    public void quickSort12(int first, int last, int column, String[][] array) {
//        int left = first;
//        int right = last;
//        String pivot = array[(left + right) / 2][column];
//        //System.out.println("debug 1 \n");
//        while (left <= right) {
//            //System.out.println("debug 2 \n");
//            while (array[left] < pivot) {
//                left++;
//            }
//            while (array[right] > pivot) {
//                right--;
//            }
//            if (left <= right) {
//                int tempNum = array[left];
//                array[left] = array[right];
//                array[right] = tempNum;
//                left++;
//                right--;
//                //System.out.println("debug 3 \n");
//                System.out.println("" + array[0] + " " + array[1] + " " + array[2] + " " + array[3]
//                        + " " + array[4] + " " + array[5] + " " + array[6]
//                        + " " + array[7] + " " + array[8] + " " + array[9]);
//            }
//        }
//        if (first < right) {
//            //System.out.println("debug 4 \n");
//            quickSort(first, right, array);
//        }
//        if (left < last) {
//            //System.out.println("debug 5 \n");
//            quickSort(left, last, array);
//        }
//    }
    /**
     * sorting a record by the column as a parameter (2D Array)
     *
     * @param first
     * @param last
     * @param column
     * @param array
     */
    public void quickSort2DArray(int first, int last, int column, String[][] array) {
        int left = first;
        int right = last;
        String pivot = array[(left + right) / 2][column];
        String[] temp;
        //System.out.println("debug 1 \n");
        while (left <= right) {
            //System.out.println("debug 2 \n");
            while (array[left][column].compareTo(pivot) < 0) {
                left++;
            }
            while (array[right][column].compareTo(pivot) > 0) {
                right--;
            }
            if (left <= right) {
                temp = array[left];
                array[left] = array[right];
                array[right] = temp;

                left++;
                right--;
                //System.out.println("debug 3 \n");
                System.out.println("" + Arrays.toString(array[0]) + " " + Arrays.toString(array[1]) + " " + Arrays.toString(array[2]) + " " + Arrays.toString(array[3])
                        + " " + Arrays.toString(array[4]) + " " + Arrays.toString(array[5]) + " " + Arrays.toString(array[6])
                        + " " + Arrays.toString(array[7]) + " " + Arrays.toString(array[8]) + " " + Arrays.toString(array[9]));
            }
        }
        if (first < right) {
            //System.out.println("debug 4 \n");
            quickSort2DArray(first, right, column, array);
        }
        if (left < last) {
            //System.out.println("debug 5 \n");
            quickSort2DArray(left, last, column, array);
        }
    }

    /*
    read file
    split lines into array
    sort by 2nd element
    re-write file
     */
    /**
     *
     * @param first
     * @param last
     * @param array
     */
    public void sortFile(String first, String last, String[][] array) {
        int left = Integer.parseInt(first);
        int right = Integer.parseInt(last);
        int pivot = Integer.parseInt(String.valueOf(array[(left + right) / 2]));
        while (left <= right) {
            while (Integer.parseInt(String.valueOf(array[left])) < pivot) {
                left++;
            }
            while (Integer.parseInt(String.valueOf(array[right])) > pivot) {
                right--;
            }
            if (left <= right) {
                String[] temp = array[left];
                array[left] = array[right];
                array[right] = temp;
                left++;
                right--;
            }
        }
        if (Integer.parseInt(first) < right) {
            //System.out.println("debug 4 \n");
            sortFile(first, String.valueOf(right), array);
        }
        if (left < Integer.parseInt(last)) {
            //System.out.println("debug 5 \n");
            sortFile(String.valueOf(left), last, array);
        }
    }

    /**
     *
     * @param array
     * @param column
     * @return
     */
    public String[][] arrangeArray(String[][] array, int column) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array.length; j++) {
                if (array[i][column].compareTo(array[j][column]) > 0) {
                    String[] temp = array[i];
                    array[i] = array[j];
                    array[j] = temp;
                }
            }
        }
        return array;
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        new Sorting();
    }
}
