package software.development;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

/**
 * Class to save all of the details of the game (player coordinates, score etc)
 *
 * @author angel
 */
public class Saver {

    /**
     *
     * @param player the player
     */
    public void savePlayer(Player player) {
        //saves the coordinates and the score, ammo, hp of the player in a text file called player.txt in the users' saves folder
        try {
            new File("users/" + Login.user + "/saves/save").mkdirs();

            FileWriter writer = new FileWriter("users/" + Login.user + "/saves/save/player.txt", false);
            BufferedWriter buffer = new BufferedWriter(writer);

            buffer.write(String.valueOf(player.getX()) + "@" + String.valueOf(player.getY()) + "\n");
            buffer.write(LevelScore.getScore() + "\n");
            buffer.write(LevelScore.getAmmo() + "\n");
            buffer.write(LevelScore.getHp() + "\n");

            updateScore();

            buffer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * updates the highest score of the player in the "highestScore" text file
     */
    public void updateScore() {
        //
        try {

            int score = LevelScore.getScore();

            File f = new File("users/" + Login.user + "/saves/highestScore.txt");

            FileWriter writer = new FileWriter("users/" + Login.user + "/saves/highestScore.txt", false);
            BufferedWriter buffer = new BufferedWriter(writer);

            if (f.length() == 0) {
                buffer.write(score + System.lineSeparator());
            } else {
                Scanner sc = new Scanner(f);
                if (Integer.parseInt(sc.next()) > LevelScore.getScore()) {

                    score = Integer.parseInt(sc.next());
                } else {
                    score = LevelScore.getScore();
                }
            }
            Highscore h = new Highscore();

            h.update(score, Login.user);
            buffer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
