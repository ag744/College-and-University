package software.development;
/**
 * Class to display a certain area of the image loaded on screen (follows
 * player)
 *
 * @author Angel
 */
public class Camera {

    /**
     * Starting x-coordinate
     */
    public float x;

    /**
     * Starting y-coordinate
     */
    public float y;

    /**
     * Constructor initialising the object
     *
     * @param x starting x-coordinate
     * @param y starting y-coordinate
     */
    public Camera(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * updates the camera every tick
     *
     * @param object focused object
     */
    public void tick(GameObject object) {

        x += ((object.getX() - x + 42) - Game.WIDTH / 2) * 0.05f; // updates the x coordinate
        y += ((object.getY() - y + 72) - Game.HEIGHT / 2) * 0.05f; // updates the y coordinate

        clamp((int) x, 0, 8000);//clamps the x and y values between 0 and 8000
        clamp((int) y, 0, 8000);
    }

    /**
     * gets the x value
     *
     * @return returns the x value
     */
    public float getX() {
        return x;
    }

    /**
     * sets the x value to the parameter's value
     *
     * @param x value to set x to
     */
    public void setX(float x) {
        this.x = x;
    }

    /**
     * gets the y value
     *
     * @return returns the value of y
     */
    public float getY() {
        return y;
    }

    /**
     * sets the y value to the parameter's value
     *
     * @param y value to set y to
     */
    public void setY(float y) {
        this.y = y;
    }

    /**
     * function to keep a changing value within limits specified 
     *
     * @param val value to be limited
     * @param min minimum of the value
     * @param max maximum of the value
     * @return returns the value. If the value exceeds the max it will be set to
     * the max so that it does not exceed it anymore and the opposite goes for
     * the min
     */
    public static int clamp(int val, int min, int max) {

        if (val >= max) {
            return val = max;
        }
        if (val <= min) {
            return val = min;
        } else {
            return val;
        }
    }
}
