package software.development;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 * Class used to create enemy objects which will move
 *
 * @author Angel
 */
public class Enemy extends GameObject {

    private BufferedImage enemy_image;
    public static Border border;
    Camera camera;

    private Handler handler;
    Random r = new Random();

    static int enemyCounter = 0;

    int x;
    int y;

    int choose = 0;
    int hp = 100;

    /**
     *
     * @param x starting x-coordinate of object
     * @param y starting y-coordinate of object
     * @param id identification of object
     * @param handler
     */
    public Enemy(int x, int y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;
        this.x = x;
        this.y = y;
//        SpriteSheet ss = new SpriteSheet(enemy_image);
//        
//        ss.grabImage(1, 1, 16, 16);
    }

    /**
     * collision detection between enemies and block, portal1, portal2,
     * doorblock, bullet, border
     */
    public void tick() {
        x += velX;//constant updating of the x and y coordinate
        y += velY;//object is moving constantly

        choose = r.nextInt(10);

        for (int i = 0; i < handler.object.size(); i++) {
            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Block
                    || tempObject.getID() == ID.Portal1
                    || tempObject.getID() == ID.Portal2
                    || tempObject.getID() == ID.DoorBlock) {

                if (getBoundsBig().intersects(tempObject.getBounds())) {

                    x += (velX * 5) * -1;
                    y += (velY * 5) * -1;
                    velX *= -1;//when the object has touched the walls of the level the program will
                    velY *= -1;//reverse the direction/velocity with which the object was moving previously

                } else if (choose == 0) {
                    velX = (r.nextInt(4 - -4)) + -4;//creates a random new direction for the object to move 
                    velY = (r.nextInt(4 - -4)) + -4;
                }

            }

            if (tempObject.getID() == ID.Bullet) {
                if (getBounds().intersects(tempObject.getBounds())) {

                    hp -= 50;//deducts 50 from the objects 
                    handler.removeObject(tempObject);
                }
            }

            if (tempObject.getID() == ID.Border) {
                if (getBounds().intersects(tempObject.getBounds())) {
                    handler.removeObject(this);//removes the enemy if it overlaps with the border
                    enemyCounter--;
                }
            }
        }

        if (hp <= 0) {
            LevelScore.score += 1000;
            handler.removeObject(this);//when an enemy is killed 1000 points are added to the score of the player
            enemyCounter--;
        }

        if (enemyCounter < 0) {
            enemyCounter = 0;//sometimes the previous if statement runs more than 
            //once if enemies are killed simultaneously (i think) so it deducts more than one per enemy killed
        }
    }

    /**
     * graphics for enemies
     *
     * @param g
     */
    public void render(Graphics g) {
        g.setColor(Color.yellow);
        g.fillRect(x, y, 32, 32);

    }

    /**
     * used for collision detection between objects
     *
     * @return
     */
    public Rectangle getBounds() {
        return new Rectangle(x, y, 32, 32);
    }

    /**
     * used to make sure enemies do not go out of the map these bounds are
     * bigger and are only used for the collision between enemy and the edge of
     * the room
     *
     * @return
     */
    public Rectangle getBoundsBig() {
        return new Rectangle(x - 16, y - 16, 64, 64);//
    }
}
