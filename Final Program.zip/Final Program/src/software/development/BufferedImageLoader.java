package software.development;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

/**
 * Used to load Buffered images so that they can be displayed
 *
 * @author Angel
 */
public class BufferedImageLoader {

    private BufferedImage image;

    /**
     * loads the buffered image
     *
     * @param path string path of file/image
     * @return returns the image/ loaded image
     */
    public BufferedImage loadImage(String path) {

        try {
            image = ImageIO.read(getClass().getResource(path));
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error " + e);
        }

        return image;
    }
}
