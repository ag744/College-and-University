package software.development;

import java.awt.Graphics;
import java.awt.Rectangle;

/**
 * Class to represent objects just outside of the walls so that if an enemy
 * glitches out of the room and collides with this object it will be removed
 *
 * @author angel
 */
public class Border extends GameObject {

    Handler handler;

    public Border(float x, float y, ID id) {
        super(x, y, id);

        Enemy.border = this;
    }

    @Override
    public void tick() {

    }

    @Override
    public void render(Graphics g) {

    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 32, 32);
    }

}
