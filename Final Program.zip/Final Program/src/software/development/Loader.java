package software.development;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author angel
 */
public class Loader {

    public LevelScore ls;
    public Handler handler;
    public Game game;
    public DoorBlock door;
    public Saver saver;
    public SpawnA spawna;

    /**
     * using the constructor to load the save from the text files
     */
    public Loader(Handler handler, LevelScore ls, Spawn spawn) {
        loadSave(handler, ls, spawn);
    }

    /*
     * loads the player, score, ammo and their health from last save made
     */
    private void loadSave(Handler handler, LevelScore ls, Spawn spawn) {
        float x = 0;
        float y = 0;
        try {
            x = returnPlayerX();
            y = returnPlayerY();

            ls.setScore(returnScore());
            ls.setAmmo(returnAmmo());
            ls.setHp(returnHP());

        } catch (Exception e) {
            Menus.error = 1;
        }

        if (Menus.error == 0) {
            handler.addObject(new Player(x, y, ID.Player, handler, game, spawn, spawna));
        }
    }

    /*
     * gets the players X-coordinates
     */
    private float returnPlayerX() {

        float x = 0;

        try {

            FileReader file = new FileReader("users/" + Login.user + "/saves/save/player.txt");
            BufferedReader reader = new BufferedReader(file);

            String lineRead;
            String[] search;

            lineRead = reader.readLine();
            search = lineRead.split("@");
            x = Float.parseFloat(search[0]);

            closeReader(file);
            closeReader(reader);

        } catch (Exception e) {
            Menus.error = 1;
        }
        return x;
    }

    /*
     * gets the players Y-coordinates
     */
    private float returnPlayerY() {

        float y = 0;

        try {

            FileReader file = new FileReader("users/" + Login.user + "/saves/save/player.txt");
            BufferedReader reader = new BufferedReader(file);

            String lineRead;
            String[] search;

            lineRead = reader.readLine();
            search = lineRead.split("@");
            y = Float.parseFloat(search[1]);

            closeReader(file);
            closeReader(reader);

        } catch (Exception e) {
            Menus.error = 1;
        }

        return y;
    }

    /*
     * gets the players score
     */
    private int returnScore() {

        int score = 0;

        String lineRead;

        try {
            BufferedReader reader = new BufferedReader(new FileReader("users/" + Login.user + "/saves/save/player.txt"));

            for (int i = 0; i < 2; i++) {
                lineRead = reader.readLine();
                if (i == 1) {
                    score = Integer.parseInt(lineRead);
                }
            }

            closeReader(reader);
        } catch (Exception e) {
            Menus.error = 1;
        }

        return score;
    }

    /*
     * gets the players ammo
     */
    private int returnAmmo() {
        int ammo = 0;

        try {
            BufferedReader reader = new BufferedReader(new FileReader("users/" + Login.user + "/saves/save/player.txt"));

            String lineRead;

            for (int i = 0; i < 3; i++) {
                lineRead = reader.readLine();
                if (i == 2) {
                    ammo = Integer.parseInt(lineRead);
                }
            }

            closeReader(reader);

        } catch (Exception e) {
            Menus.error = 1;
        }

        return ammo;
    }

    /*
     * gets the players health
     */
    private int returnHP() {
        int hp = 0;

        try {
            BufferedReader reader = new BufferedReader(new FileReader("users/" + Login.user + "/saves/save/player.txt"));

            String lineRead;
            for (int i = 0; i < 4; i++) {
                lineRead = reader.readLine();
                if (i == 3) {
                    hp = Integer.parseInt(lineRead);
                }
            }

            closeReader(reader);
        } catch (Exception e) {
            Menus.error = 1;
        }

        return hp;
    }

    /*
     *closing readers using overloading of methods
     */
    private void closeReader(BufferedReader reader) throws Exception {
        reader.close();
    }

    private void closeReader(FileReader reader) throws Exception {
        reader.close();
    }

}
