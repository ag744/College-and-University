package software.development;

import java.awt.Graphics;
import java.awt.Rectangle;

/**
 * Abstract class used to ease the creation of the same class over and over. Has
 * a build in tick(), render() and getBounds() method also has x, y, velX, velY
 * and ID protected values
 *
 * @author Angel
 */
public abstract class GameObject {

    //integers that all objects will have, hence they are protected
    /**
     *
     */
    protected float x;

    /**
     *
     */
    protected float y;

    /**
     *
     */
    protected ID id;

    /**
     *
     */
    protected float velX;

    /**
     *
     */
    protected float velY;

    /**
     * constructor used to indicate parameters refer to protected values of this
     * class
     *
     * @param x
     * @param y
     * @param id
     */
    public GameObject(float x, float y, ID id) {
        this.x = x;
        this.y = y;
        this.id = id;

    }

    /**
     * used to update the object
     */
    public abstract void tick();

    /**
     * used to render graphics of the object
     *
     * @param g
     */
    public abstract void render(Graphics g);

    /**
     * used for collision detection
     *
     * @return
     */
    public abstract Rectangle getBounds();

    /**
     * getters and setters for the protected values
     *
     * @param id
     */
    public void setID(ID id) {
        this.id = id;
    }

    /**
     *
     * @return
     */
    public ID getID() {
        return id;
    }

    /**
     *
     * @return
     */
    public float getX() {
        return x;
    }

    /**
     *
     * @return
     */
    public float getY() {
        return y;
    }

    /**
     *
     * @return
     */
    public float getVelX() {
        return velX;
    }

    /**
     *
     * @return
     */
    public float getVelY() {
        return velY;
    }

    /**
     *
     * @param x
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     *
     * @param y
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     *
     * @param velX
     */
    public void setVelX(int velX) {
        this.velX = velX;
    }

    /**
     *
     * @param velY
     */
    public void setVelY(int velY) {
        this.velY = velY;
    }

}
