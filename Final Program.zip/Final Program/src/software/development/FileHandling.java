package software.development;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 * Class used to add edit and delete records from text files
 *
 * @author Angel
 */
public class FileHandling {

    /**
     * closes all reader and writers
     */
    public static void closeReaderWriter(FileReader reader, BufferedReader buffer, FileWriter writer) throws IOException {
        writer.close();
        reader.close();
        buffer.close();
    }

    /**
     * outputs all of the data from the array passed in as a parameter
     *
     * @param search array containing id, username, password, email, re-entered
     * email and date of birth
     * @param user instance of Register class, used to refer to text fields
     */
    public static void output(String[] search, Register user) {

        user.getIdTxt1().setText(search[0]);
        user.getUsernameTxt1().setText(search[1]);
        user.getPassTxt1().setText(search[2]);
        user.getRePassTxt1().setText(search[2]);
        user.getEmailTxt1().setText(search[3]);
        user.getReEmailTxt1().setText(search[4]);
        user.getDobTxt1().setText(search[5]);

    }

    /**
     * clears all the fields
     *
     * @param user instance of Register class, used to refer to text fields
     */
    public static void clear(Register user) {

        user.getIdTxt1().setText("");
        user.getUsernameTxt1().setText("");
        user.getPassTxt1().setText("");
        user.getRePassTxt1().setText("");
        user.getEmailTxt1().setText("");
        user.getReEmailTxt1().setText("");
        user.getDobTxt1().setText("");
    }

    /**
     * deletes a record from the text file using the id of the user
     *
     * method makes two files, "temp" and "registrations". Takes everything from
     * the "registrations" file and writes everything from it to the "temp" file
     * without the searched user, hence deleting the record
     *
     * @param userId id of the user
     */
    public static void delete(String userId) {

        File temp = new File("temp.txt");
        File newFile = new File("registrations.txt");

        String line;
        String[] data;

        boolean found = false;
        boolean deleted = false;
        boolean renamed = false;

        try {
            FileReader reader = new FileReader(newFile);
            BufferedReader buffer = new BufferedReader(reader);
            FileWriter writer = new FileWriter(temp);

            while ((line = buffer.readLine()) != null) {

                data = line.split(",");

                if (data[0].equals(userId)) {
                    found = true;
                } else {
                    writer.write(line + "\n");
                }
            }
            closeReaderWriter(reader, buffer, writer);

            if (found == true) {
                System.out.println("Found = " + found);
                JOptionPane.showMessageDialog(null, "Record deleted");
                deleted = newFile.delete();
                renamed = temp.renameTo(newFile);
            }
            if (found == false) {
                JOptionPane.showMessageDialog(null, "Record not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * overwrites the data saved for the searched user
     *
     * method makes two files, "temp" and "registrations". Takes everything from
     * the "registrations" file and writes everything from it to the "temp" file
     * with the altered value of the searched user
     *
     * Then deletes the "registrations" file and renames the file "temp" to
     * "registrations"
     *
     * @param user instance of Register class, used to refer to text fields
     */
    public static void edit(Register user) {

        File temp = new File("temp.txt");
        File newFile = new File("registrations.txt");

        boolean found = false;
        boolean deleted = false;
        boolean renamed = false;

        String record;
        String[] data;
        String joinedUp;

        try {
            FileReader reader = new FileReader(newFile);
            BufferedReader buffer = new BufferedReader(reader);
            FileWriter writer = new FileWriter(temp);

            while ((record = buffer.readLine()) != null) {
                data = record.split(",");

                if (data[0].equals(user.getIdTxt1().getText())) {
                    found = true;

                    data[1] = (user.getUsernameTxt1().getText());
                    data[2] = (String.valueOf(user.getPassTxt1().getPassword()));
                    data[3] = (user.getEmailTxt1().getText());
                    data[4] = (user.getReEmailTxt1().getText());

                    joinedUp = String.join(",", data);

                    writer.write(joinedUp + "\n");
                } else {
                    writer.write(record + "\n");
                }
            }
            closeReaderWriter(reader, buffer, writer);
            if (found == true) {
                JOptionPane.showMessageDialog(null, "Record edited");
                deleted = newFile.delete();
                renamed = temp.renameTo(newFile);
            }
            if (found == false) {
                JOptionPane.showMessageDialog(null, "Record not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * writes all details to a text file
     *
     * @param file text file to be written to
     * @param user instance of Register class, used to refer to text fields
     */
    public static void save(String file, Register user) {
        String[] saveArray = new String[6];

        String joinedUp;

        saveArray[0] = user.getIdTxt1().getText();
        saveArray[1] = user.getUsernameTxt1().getText();
        saveArray[2] = String.valueOf(user.getPassTxt1().getPassword());
        saveArray[3] = user.getEmailTxt1().getText();
        saveArray[4] = user.getReEmailTxt1().getText();
        saveArray[5] = user.getDobTxt1().getText();

        try {
            FileWriter writer = new FileWriter(file, true);
            joinedUp = String.join(",", saveArray);
            writer.write("\r\n" + joinedUp);
            writer.close();

            clear(user);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * linear search to search through all registered users
     *
     * @param file file to search in
     * @param user instance of Register class, used to refer to text fields
     */
    public static void searchLinear(String file, Register user) {
        boolean found = false;

        String[] search;
        String searchRead;
        try {

            FileReader reader = new FileReader(file);
            BufferedReader buffer = new BufferedReader(reader);

            while ((searchRead = buffer.readLine()) != null || found == true) {
                search = searchRead.split(",");
                if (search[0].equals(user.getIdTxt1().getText())) {
                    FileHandling.output(search, user);
                    found = true;
                    break;
                } else {
                    found = false;
                }

            }
            reader.close();
            buffer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (found == false) {
            JOptionPane.showMessageDialog(null, "Record does not exist", "Alert", JOptionPane.ERROR_MESSAGE);
            user.getIdTxt1().setText("");
        }
    }
}
