package software.development;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 * Class to represent and display a bullet object on the screen which
 *
 * @author Angel
 */
public class Bullet extends GameObject {

    private Handler handler;

    /**
     *
     * @param x x coordinate of object
     * @param y y coordinate of object
     * @param id id of object
     * @param handler instance of handler
     * @param mx mouse x coordinate
     * @param my mouse y coordinate
     */
    public Bullet(float x, float y, ID id, Handler handler, int mx, int my) {
        super(x, y, id);
        this.handler = handler;

        velX = (mx - x) / 10;
        velY = (my - y) / 10;

    }

    /**
     * collision detection of bullet with other objects, if bullet collides with
     * any of the id's listed, the bullet will be removed
     */
    public void tick() {
        x += velX;
        y += velY;

        for (int i = 0; i < handler.object.size(); i++) {
            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Block || tempObject.getID() == ID.Border || tempObject.getID() == ID.DoorBlock || tempObject.getID() == ID.Portal1 || tempObject.getID() == ID.Portal2) {
                if (getBounds().intersects(tempObject.getBounds())) {

                    handler.removeObject(this);
                }
            }
        }
    }

    /**
     * graphics of object
     *
     * @param g
     */
    public void render(Graphics g) {
        g.setColor(Color.green);
        g.fillOval((int) x, (int) y, 16, 8);
    }

    /**
     * hit-box of bullet
     *
     * @return
     */
    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 15, 15);
    }

}
