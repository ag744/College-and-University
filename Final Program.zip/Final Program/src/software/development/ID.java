package software.development;

/**
 * put an id for an object self-explanatory really for the names
 *
 * @author Angel
 */
public enum ID {

    /**
     * player object
     */
    Player(),
    /**
     * edge of room
     */
    Block(),
    /**
     * ammo crate
     */
    Crate(),
    /**
     * bullet object
     */
    Bullet(),
    /**
     * normal enemy
     */
    Enemy(),
    /**
     * left portal
     */
    Portal1(),
    /**
     * right portal
     */
    Portal2(),
    /**
     * used to block the portal for the next/previous room
     */
    DoorBlock(),
    /**
     * enemy that follows you
     */
    SmartEnemy(),
    /**
     * used outside the rooms as a layer of kill area where if an enemy is
     * touching it it will kill the enemy this is done because the movement
     * mechanism for the enemies is random enough to make them glitch out of the
     * room, hence i decided to use this to remove them if that happened
     */
    Border();

}
