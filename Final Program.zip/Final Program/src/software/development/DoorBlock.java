package software.development;

import java.awt.Graphics;
import java.awt.Rectangle;

/**
 * Used when player is in a room and if they haven't killed all the enemies, it
 * will not let them through to the next level
 *
 * @author gel17835534
 */
public class DoorBlock extends GameObject {

    Handler handler;

    public DoorBlock(int x, int y, ID id) {
        super(x, y, id);

        Player.door = this;
    }

    @Override
    public void tick() {
    }

    @Override
    public void render(Graphics g) {
    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 32, 128);//object is 32x128 pixels
    }
}
