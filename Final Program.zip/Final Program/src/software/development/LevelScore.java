package software.development;

import software.development.Game.STATE;
import java.awt.Color;
import java.awt.Graphics;

/**
 * used to keep track of the score, health and ammo of player
 *
 * @author gel17835534
 */
public class LevelScore {

    private Game game;
    private Spawn spawn;
    private Login login;

    /**
     * initial ammo for player object
     */
    public static int ammo = 50;

    /**
     * initial health for player objects
     */
    public static int hp = 400;

    /**
     * initial score of user
     */
    public static int score = 0;

    /**
     *
     * @param game
     * @param spawn
     * @param login
     */
    public LevelScore(Game game, Spawn spawn, Login login) {
        this.game = game;
        this.spawn = spawn;
        this.login = login;
    }

    /**
     * increments the score variable every tick
     */
    public void tick() {

//        score++;

    }

    /**
     * used to draw the health bar and to display the score
     *
     * @param g
     */
    public void render(Graphics g) {

        if (game.gameState == STATE.game) {

            g.setColor(Color.gray);
            g.fillRect(5, 5, 200, 32);

            g.setColor(Color.green);
            g.fillRect(5, 5, hp, 32);

            g.setColor(Color.black);
            g.drawRect(5, 5, 200, 32);

            g.setColor(Color.white);

            g.drawString("Ammo: " + ammo, 5, 50);
            g.drawString("Score: " + score, 5, 70);
            g.drawString("User: " + Login.user, 5, 90);
        }
    }

    /**
     * getters and setters for variables
     */
    public static int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public static int getAmmo() {
        return ammo;
    }

    public void setAmmo(int ammo) {
        LevelScore.ammo = ammo;
    }

    public static int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        LevelScore.hp = hp;
    }

}
