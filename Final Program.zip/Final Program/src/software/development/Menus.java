package software.development;

import software.development.Game.STATE;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileReader;

/**
 * Class used to display the different menus for the different game states
 *
 * @author gel17835534
 */
public class Menus extends MouseAdapter {

    public Game game;
    public static Player player;
    public static Enemy enemy;

    private Saver saver;
    private Handler handler;
    private LevelScore ls;
    private Spawn spawn;
    private Camera camera;
    private Highscore hs;

    static int error = 0;

    /**
     * Constructor indicating parameters refer to private values/objects
     *
     * @param game main class object
     * @param handler handler object
     * @param ls level and score object
     * @param spawn spawn object
     * @param camera camera object
     * @param hs highscore object
     * @param enemy enemy object
     * @param saver saver object
     * @param player player object
     */
    public Menus(Game game, Handler handler, LevelScore ls, Spawn spawn, Camera camera, Highscore hs, Enemy enemy, Saver saver, Player player) {
        this.game = game;
        this.handler = handler;
        this.ls = ls;
        this.spawn = spawn;
        this.camera = camera;
        this.hs = hs;
        this.enemy = enemy;
        this.saver = saver;
        this.player = player;
    }

    /**
     * Method used when the mouse is pressed
     *
     * @param e left click of mouse
     */
    @Override
    public void mousePressed(MouseEvent e) {

        int mx = e.getX();// gets the x coordinates of the mouse when the left button is pressed
        int my = e.getY();// gets the y coordinates of the mouse when the left button is pressed

        if (game.gameState == STATE.menu) { //if the state of the game is the menu state (if the player is in the Main Menu)
            if (mouseOver(mx, my, 400, 175, 200, 50)) {//if the user has his mouse pointer within these values
                game.gameState = STATE.load;//load the save for that player
            }
            if (mouseOver(mx, my, 400, 250, 200, 50)) {
                game.gameState = STATE.highscores;//set gamestate to highscores state
//                System.out.println(game.gameState);
            }
            if (mouseOver(mx, my, 400, 325, 200, 50)) {
                game.gameState = STATE.help;//set gamestate to help state
            }
            if (mouseOver(mx, my, 400, 400, 200, 50)) {
                System.exit(0);//exit the game

            }
        }

        if (game.gameState == STATE.end) {//save the game if the player finished the game
            saver.savePlayer(this.player);
        }

        if (game.gameState == STATE.load) {
            if (mouseOver(mx, my, 180, 235, 200, 50)) {

                handler.object.clear();//remove all objects from LinkedList
                Enemy.enemyCounter = 0;//no enemies
                ls.setAmmo(50);//reset values AHS
                ls.setHp(200);
                ls.setScore(0);

                game.loadLevel(game.allRooms);//load the rooms
                spawn.currentRoom = 0;// sets the current room to 0 (value which determines where the player is spawned, set to 0 to avoid confusion with addition and subtraction)
                game.gameState = STATE.game;//set the state of the game to the game state

                error = 0;

            }
            if (mouseOver(mx, my, 610, 235, 200, 50)) {

                new Loader(handler, ls, spawn);

                if (error == 0) {
                    game.loadLevel(game.blank);//uses a blank image of all of the rooms so that no new players are spawned by accident
                    game.gameState = STATE.game;
                    spawn.currentRoom = 0;
                }
            }
        }

        if (game.gameState == STATE.help) {
            if (mouseOver(mx, my, 400, 400, 200, 50)) {//back button
                game.gameState = STATE.menu;
            }
        }

        if (game.gameState == STATE.highscores) {
            if (mouseOver(mx, my, 770, 415, 200, 50)) {//back button
                game.gameState = STATE.menu;
            }
        }

        if (game.gameState == STATE.death) {//when the player dies a message is displayed(game over) and a box is also displayed
            if (mouseOver(mx, my, 400, 325, 200, 50)) {//if the player clicks on the box(try again)
                game.gameState = STATE.load;
            }
            if (mouseOver(mx, my, 400, 400, 200, 50)) {//menu button
                game.gameState = STATE.menu;
            }
        }

        if (Game.paused) {
            if (mouseOver(mx, my, 400, 250, 200, 50)) {// Resume Button
                if (e.getButton() == MouseEvent.BUTTON1) {
                    if (!Game.paused) {
                        Game.paused = true;
                    }
                    Game.paused = false;
                }
            }
            if (mouseOver(mx, my, 400, 325, 200, 50)) {// save button
                if (Enemy.enemyCounter == 0) {
                    saver.savePlayer(player);
                }
            }
            if (mouseOver(mx, my, 400, 400, 200, 50)) {// End Run button
                try {

                    if (handler.object.getFirst() != null) {
//                    handler.object.clear(); //if the below statement throws exception put this one in, sometimes one of them works better than the other
                        handler.removeAll(handler.object);
                        game.gameState = STATE.menu;
                        Game.paused = false;
                        ls.setScore(0);
                        ls.setAmmo(50);
                        ls.setHp(200);
                        camera.x = 0;
                        camera.y = 0;
                        Enemy.enemyCounter = 0;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        }

    }

    /**
     *
     */
    public void mouseReleased() {

    }

    /**
     *
     */
    public void tick() {

    }

    /**
     *
     * @param g
     */
    public void render(Graphics g) {
        if (game.gameState == STATE.death) {

            handler.object.clear();//removes all objects when player dies

            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);

            //displays text onto screen with different fonts
            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Game Over", 380, 50);

            g.setFont(fnt2);
            g.drawString("You died with a score of " + LevelScore.getScore(), 350, 200);

            g.drawRect(400, 325, 200, 50);
            g.drawString("Try Again", 435, 360);

            g.drawRect(400, 400, 200, 50);
            g.drawString("Menu", 465, 435);

        }
        if (game.gameState == STATE.menu) {
            //displays text onto screen with different fonts
            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);

            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Menu", 445, 50);

            g.setFont(fnt2);
            g.drawRect(400, 175, 200, 50);
            g.drawString("Play", 470, 214);

            g.drawRect(400, 250, 200, 50);
            g.drawString("Highscores", 420, 283);

            g.drawRect(400, 325, 200, 50);
            g.drawString("Help", 470, 360);

            g.drawRect(400, 400, 200, 50);
            g.drawString("Quit", 470, 435);

        }

        if (game.gameState == STATE.load) {
            //displays text onto screen with different fonts
            g.setColor(Color.white);
            g.setFont(new Font("arial", 1, 30));

            g.drawRect(180, 235, 200, 50);
            g.drawRect(610, 235, 200, 50);

            g.drawString("New Game", 200, 270);
            g.drawString("Load Save", 630, 270);

            if (error == 1) {
                g.drawString("No save found", 390, 400);
            }
        }

        if (game.gameState == STATE.highscores) {

            String line;
            String username;
            String score;
            String[] array;

            int y = 100;

            int x1 = 50;
            int y1 = 100;

            g.setColor(Color.white);
            g.setFont(new Font("arial", 1, 30));

            for (int i = 1; i < 11; i++) {//draws 1-10 numbers for highscores

                g.drawString(i + ".", x1, y1);

                y1 += 40;
            }

            g.drawString("Highscores", 420, 50);

            g.drawRect(770, 415, 200, 50);
            g.drawString("Back", 835, 450);

            try {
                BufferedReader reader = new BufferedReader(new FileReader("temp.txt"));

                while ((line = reader.readLine()) != null) {
                    array = line.split(",");

                    username = array[0];
                    score = array[1];

                    g.drawString(username, 120, y);
                    g.drawString(score, 500, y);

                    y += 40;

                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        if (Game.paused == true) {//when game is paused

            g.setColor(new Color(64, 64, 64, 245));
            g.fillRect(0, 0, Game.WIDTH, Game.HEIGHT);

            g.setFont(new Font("arial", 4, 22));
            g.setColor(Color.white);
            g.drawString("Paused", 450, 50);

            g.drawRect(400, 250, 200, 50);
            g.drawString("Resume", 465, 283);

            g.drawRect(400, 325, 200, 50);
            g.drawString("Save", 480, 360);

            g.drawRect(400, 400, 200, 50);
            g.drawString("End run", 465, 435);
        }

        if (game.gameState == STATE.help) {//when help button is pressed
            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);

            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Help", 445, 50);

            g.setFont(fnt2);

            g.drawRect(400, 400, 200, 50);
            g.drawString("Back", 470, 435);

            g.drawRect(80, 200, 50, 50);
            g.drawString("A", 95, 235);

            g.drawRect(140, 200, 50, 50);
            g.drawString("S", 155, 235);

            g.drawRect(200, 200, 50, 50);
            g.drawString("D", 215, 235);

            g.drawRect(140, 140, 50, 50);
            g.drawString("W", 150, 175);

            g.drawRoundRect(600, 100, 100, 200, 60, 60);
            g.drawLine(650, 100, 650, 160);

            g.setColor(Color.red);
            g.setFont(new Font("arial", 1, 20));

            g.drawString("Movement controls", 75, 290);

            g.drawLine(625, 120, 580, 90);
            g.drawString("LMB - select", 500, 90);

            g.drawLine(675, 120, 720, 160);
            g.drawString("RMB - shoot", 740, 180);

            g.setFont(new Font("arial", 1, 30));
            g.drawString("Saves are only available if all enemies \nfrom current room are cleared", 10, 370);

        }

        if (game.gameState == STATE.end) {//when player beats game
            g.setColor(Color.white);
            g.setFont(new Font("arial", 1, 40));
            g.drawString("Congratulations!", 345, 150);
            g.drawString("You completed the game with a score of: " + LevelScore.getScore(), 95, 227);
        }

    }

    private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
        //method to detect where the mouse is and if it is within the 
        //bounds in parameters it will return true false which will cause an action
        if (mx > x && mx < x + width) {
            if (my > y && my < y + height) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}
