package software.development;


import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 * Class representing the object which the player and enemies collide with (also
 * is the wall of the level)
 *
 * @author Angel
 */
public class Block extends GameObject {

    private BufferedImage wall2;

    /**
     *
     * @param x starting x-coordinate of object
     * @param y starting y-coordinate of object
     * @param id identification of object
     */
    public Block(int x, int y, ID id) {
        super(x, y, id);

        SpriteSheet ss = new SpriteSheet(Game.tiles);
        wall2 = ss.grabImage(1, 1, 32, 32);
    }

    /**
     * does not do anything
     */
    public void tick() {

    }

    /**
     * is just an object that the enemies and player collide with draws the
     * object on-screen
     *
     * @param g used to draw the graphics of the object on screen
     */
    public void render(Graphics g) {
//        g.setColor(Color.red);
//        g.fillRect(x, y, 32, 32);

        g.drawImage(wall2, (int)x, (int)y, null);
    }

    /**
     * used as a hit-box mechanism
     *
     * @return returns the hit-box
     */
    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 32, 32);
    }


}
