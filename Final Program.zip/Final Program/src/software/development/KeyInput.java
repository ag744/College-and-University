package software.development;

import software.development.Game.STATE;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 * Class which handles the keyboard input by the user
 *
 * @author Angel
 */
public class KeyInput extends KeyAdapter {

    Handler handler;
    private Game game;
    private Spawn spawn;

    static boolean keyRun = true;

    /**
     *
     * @param handler
     * @param game
     * @param spawn
     */
    public KeyInput(Handler handler, Game game, Spawn spawn) {
        this.handler = handler;
        this.spawn = spawn;
        this.game = game;
    }

    public void keyPressed(KeyEvent e) {

        int key = e.getKeyCode();

        if (game.gameState == STATE.game) {
            for (int i = 0; i < handler.object.size(); i++) {
                GameObject tempObject = handler.object.get(i);

                if (tempObject.getID() == ID.Player) {
                    //sets the booleans to true if the button is pressed
                    if (key == KeyEvent.VK_W) {//move up
                        handler.setUp(true);
                    }
                    if (key == KeyEvent.VK_S) {//move down
                        handler.setDown(true);
                    }
                    if (key == KeyEvent.VK_D) {//move right
                        handler.setRight(true);
                    }
                    if (key == KeyEvent.VK_A) {//move left
                        handler.setLeft(true);
                    }
                    if (key == KeyEvent.VK_ESCAPE) {//pauses the game
                        if (!Game.paused) {
                            Game.paused = true;
                        } else {
                            Game.paused = false;
                        }
                    }
                    if (key == KeyEvent.VK_ALT && key == KeyEvent.VK_F4) {//exits the game if Alt+F4 is pressed
                        System.exit(0);
                    }

                }
            }
        }
    }

    public void keyReleased(KeyEvent e) {

        int key = e.getKeyCode();

        for (int i = 0; i < handler.object.size(); i++) {
            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Player) {
                if (key == KeyEvent.VK_W) {//stop moving up
                    handler.setUp(false);
                }
                if (key == KeyEvent.VK_S) {//stop moving down
                    handler.setDown(false);
                }
                if (key == KeyEvent.VK_D) {//stop moving right
                    handler.setRight(false);
                }
                if (key == KeyEvent.VK_A) {//stop moving left
                    handler.setLeft(false);
                }
            }
        }
    }
}
