package software.development;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 * Class used to update and render the player object
 *
 * @author Angel
 */
public class Player extends GameObject {

    Handler handler;
    private Game game;
    Spawn spawn;
    private BufferedImage player1;
    public static DoorBlock door;
    private SpawnA spawna;

//    int counter = 0;
//    int x;
//    int y;
//    int velX;
//    int velY;
    /**
     *
     * @param x
     * @param y
     * @param id
     * @param handler
     * @param game
     * @param spawn
     * @param spawna
     */
    public Player(float x, float y, ID id, Handler handler, Game game, Spawn spawn, SpawnA spawna) {
        super(x, y, id);

        this.x = x;
        this.y = y;
        this.game = game;
        this.handler = handler;
        this.spawn = spawn;

        SpriteSheet ss = new SpriteSheet(Game.player_male2);
        player1 = ss.grabImage(1, 1, 63, 133);

        Menus.player = this;
        SmartEnemy.player = this;
        Spawn.player = this;

    }

    /**
     * updates the velocity of the object, collision detection and movement
     */
    @Override
    public void tick() {

        x += velX;
        y += velY;
//        System.out.println("coords of player: " + x + " " + y);
        collision();

        //makes sure there is no lag between up/down and left/right movement
        if (handler.isUp()) {
            velY = -5;
        } else if (!handler.isDown()) {
            velY = 0;
        }

        if (handler.isDown()) {
            velY = 5;
        } else if (!handler.isUp()) {
            velY = 0;
        }

        if (handler.isLeft()) {
            velX = -5;
        } else if (!handler.isRight()) {
            velX = 0;
        }

        if (handler.isRight()) {
            velX = 5;
        } else if (!handler.isLeft()) {
            velX = 0;
        }

    }

    private void collision() {
        //collision detection method
        for (int i = 0; i < handler.object.size(); i++) {

            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Block) {//if the player interacts with a block object

                if (getBounds().intersects(tempObject.getBounds())) {//player cannot go beyond this object
                    x += velX * -1;
                    y += velY * -1;
                }
            }
            if (tempObject.getID() == ID.Crate) {//if the player interacts with a crate object

                if (getBounds().intersects(tempObject.getBounds())) {//adds 10 ammo to players ammo and removes the crate
                    LevelScore.ammo += 10;
                    handler.removeObject(tempObject);
                }
            }
            if (tempObject.getID() == ID.Enemy) {//if the player interacts with an enemy object

                if (getBounds().intersects(tempObject.getBounds())) {//removes 20 health from player and removes the enemy
                    LevelScore.hp = LevelScore.hp - 20;
                    handler.removeObject(tempObject);
                    Enemy.enemyCounter--;
                }
            }

            if (tempObject.getID() == ID.SmartEnemy) {//if the player interacts with a smart enemy
                if (getBounds().intersects(tempObject.getBounds())) {//removes 10 health from player per tick
                    LevelScore.hp = LevelScore.hp - 10;
                }
            }

            if (tempObject.getID() == ID.Portal1) {//if the player interacts with left portal

                if (getBounds().intersects(tempObject.getBounds())) {//spawns a new player in theprevious room
                    spawn.spawnLeft(this);
                    break;
                }
            }
            if (tempObject.getID() == ID.Portal2) {//if the player interacts with right portal

                if (getBounds().intersects(tempObject.getBounds())) {//spawns a new player in the next room
                    spawn.spawnRight(this);
                    break;
                }
            }
            if (tempObject.getID() == ID.DoorBlock) {//if the player interacts with a door block

                if (getBounds().intersects(tempObject.getBounds())) {
                    System.out.println(Enemy.enemyCounter);
                    if (Enemy.enemyCounter != 0) {
                        x += velX * -1;
                        y += velY * -1;
                    }
                }
            }
        }
    }

    /**
     * graphics for player
     *
     * @param g
     */
    @Override
    public void render(Graphics g) {

//        g.setColor(Color.white);
//        g.fillRect((int) x, (int) y, 20, 40);//for player with no image
        g.drawImage(player1, (int) x, (int) y, null);

//        g.setColor(Color.magenta);//for hitbox graphic
//        g.drawRect((int) x + 16, (int) y + 18, 35, 114);
    }

    /**
     * hit-box for player
     *
     * @return
     */
    @Override
    public Rectangle getBounds() {
        return new Rectangle((int) x + 16, (int) y + 18, 35, 114);
//        return new Rectangle((int) x, (int) y, 20, 40);//for player with no image
    }

}
