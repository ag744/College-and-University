package software.development;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Class is an Action Listener which watches the mouse actions
 *
 * @author Angel
 */
public class MouseInput extends MouseAdapter {

    private Handler handler;
    private Camera camera;
    private Game game;
    private Spawn spawn;

    /**
     * Constructor of the class referencing the private values are the
     * parameters
     *
     * @param handler handler object
     * @param camera camera object
     * @param game main class object
     * @param spawn spawn object
     */
    public MouseInput(Handler handler, Camera camera, Game game, Spawn spawn) {
        this.handler = handler;
        this.camera = camera;
        this.game = game;
        this.spawn = spawn;
    }

    /**
     * when the player presses a button on the mouse
     *
     * @param e when the user presses Button3 of the mouse (right click by
     * default)
     */
    @Override
    public void mousePressed(MouseEvent e) {

        int mx = (int) (e.getX() + camera.getX());//mouse x coordinate casted as an integer
        int my = (int) (e.getY() + camera.getY());//mouse y coordinate casted as an integer

        if (Game.paused == false) {//if the game is not paused// and the 
            for (int i = 0; i < handler.object.size(); i++) {//loop through the LinkedList
                GameObject tempObject = handler.object.get(i);

                if (e.getButton() == MouseEvent.BUTTON3) {//if the button clicked is the right button of the mouse
                    if (tempObject.getID() == ID.Player && LevelScore.ammo >= 1) {// and if the id of the object in the 
                        //LinkedList is a player object and the ammo is 1 or above
                        handler.addObject(new Bullet((int)tempObject.getX() + 24, (int)tempObject.getY() + 50, ID.Bullet, handler, mx, my));
                        //spawn a bullet which travelles from the player to the mouse coordinates
                        
                        LevelScore.ammo--;//deduct 1 from the ammunition that the player has

                    }
                }
            }
        }
    }
}
