{- *** Question 2.1 *** -}
main ::IO()
main = putStrLn (pretty (take 3 ([[["a","b","c"],["4","5","6"]],[["7","8","9"],["4","5","6"]]])))

{- function to flatten the triple String list to a double String list -}
flattenList:: [[[String]]] -> [[String]]
flattenList xs = concat xs

{- function to remove special characters -}
removeSpecial :: String -> String
removeSpecial (x:xs) = [ x | x <- xs, not (x `elem` ",.?!-:;\"\' []") ]

{- function to add the lists together -}
addList :: [[String]] -> String
addList [x] = [] 
addList (x:xs) = (addN (removeSpecial (show x))) ++ (addList xs)

{- function to add "\n" at the end of a string -}
addN :: String -> String 
addN x = x ++ "\n"

{- fucntion used to pretty-print a possibly-infinite sequence of generations -}
pretty :: [[[String]]] -> String
pretty xs = show (addList (flattenList xs))

{- *** Question 2.2 ***-}

main :: IO()
main = putStrLn(show())

type Point = (Int, Int)

glider :: [Point]
glider = [ (0, 2), (1, 3), (2, 1), (2, 2), (2, 3) ]

-- visualisation :: Int -> Int -> [[Point]] -> [[String]]
-- visualisation rows columns xs = map show (tuplesToList(flattenPoint xs)) rows

{- function to convert from tuples to list -}
tuplesToList :: [Point] -> [Int]
tuplesToList xs = concatMap (\(x,y) -> [x,y]) xs

{- function to replace the nth character in a string -}
replaceNth :: Int -> a -> [a] -> [a]
replaceNth _ _ [] = []
replaceNth n newVal (x:xs)
  | (n == 0) = newVal : xs
  | otherwise = x : replaceNth (n-1) newVal xs

{- function to flatten the double list to a single list -}
flattenPoint :: [[Point]] -> [Point]
flattenPoint xs = concat xs

{- *** Question 2.3 ***-}

main ::IO()
main = putStrLn ("")

type Point = (Int, Int)

glider :: [ Point ]
glider = [ (0, 2), (1, 3), (2, 1), (2, 2), (2, 3) ]

{- function to work out survivor cells form the current generation -}
survivorCells :: [Point] -> [Point]
survivorCells points = [p | p <- points, elem (alive points p) [2,3]]

{- function to work out the new living cells for the next generation from the current generation -}
newCells :: [Point] -> [Point]
newCells points = [p | p <- concat (map surrounding points), getDead points p, alive points p == 3]

{- function to get the amount of living cells on the current generation -}
alive :: [Point] -> Point -> Int
alive b = length . filter (getAlive b) . surrounding

{- function to return the surrounding cells of one cell -}
surrounding :: Point -> [Point]
surrounding (x,y) = [ ((x-1), (y-1)), ((x), (y-1)), ((x+1), (y-1)), ((x-1), (y)), ((x+1), (y)), ((x-1), (y+1)), ((x), (y+1)), ((x-1), (y+1)) ]

{- function to prove that a cell is alive -}
getAlive :: [Point] -> Point -> Bool
getAlive points p = elem p points

{- function to prove that a cell is not alive -}
getDead :: [Point] -> Point -> Bool
getDead points p = not (getAlive points p)
