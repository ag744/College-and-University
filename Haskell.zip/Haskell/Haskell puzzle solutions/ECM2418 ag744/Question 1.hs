main :: IO ()
main =  putStrLn(show(question1))

{- *** Question 1 *** -}
question1 :: [(Int, Int, Int, Int, Int, Int)]
question1 = filter rule6 rule5

{- *** Question 1.1 *** -}
rule1 :: (Int, Int, Int, Int, Int, Int) -> Bool
rule1(x1, x2, x3, x4, x5, x6)
  | ((x1==x2) || (x1==x3) || (x1==x4) || (x1==x5) || (x1==x6) || (x2==x3) || (x2==x4) || (x2==x5) || (x2==x6) || (x3==x4) || (x3==x5) || (x3==x6) || (x4==x5) || (x4==x6) || (x5==x6)) = False
  | otherwise = True

{- *** Question 1.2 *** -}
rule2 :: (Int, Int, Int, Int, Int, Int) -> Bool
rule2(x1, x2, x3, x4, x5, x6)
  | ( ((all even[x1, x3, x5]) && (all odd[x2, x4, x6])) || ((all odd[x1, x3, x5]) && (all even[x2, x4, x6])) ) = True
  | otherwise = False

{- *** Question 1.3 *** -}
rule3 :: (Int, Int, Int, Int, Int, Int) -> Bool
rule3(x1, x2, x3, x4, x5, x6)
  | abs(x1-x2) > 2 && abs(x2-x3) > 2 && abs(x3-x4) > 2 && abs(x4-x5) > 2 && abs(x5-x6) > 2 = True
  | otherwise = False

{- *** Question 1.4 *** -}
rule4 :: (Int, Int, Int, Int, Int, Int) -> Bool
rule4(x1, x2, x3, x4, x5, x6)
  | (x1x2 `mod` x5x6 == 0) && (x3x4 `mod` x5x6 == 0) = True
  | otherwise = False
    where   
     x1x2 = x1*10 + x2
     x3x4 = x3*10 + x4
     x5x6 = x5*10 + x6

{- *** Question 1.5 *** -}
rule5 :: [(Int,Int,Int,Int,Int,Int)]
rule5 = [(a,b,c,d,e,f) | a <- x, b <- x, c <- x, d <- x, e <- x, f <- x]
  where x = [0..9]

{- *** Question 1.6 *** -}
rule6 :: (Int, Int, Int, Int, Int, Int) -> Bool
rule6 (x1,x2,x3,x4,x5,x6) 
  | rule1(x1,x2,x3,x4,x5,x6) && rule2(x1,x2,x3,x4,x5,x6) && rule3(x1,x2,x3,x4,x5,x6) && rule4(x1,x2,x3,x4,x5,x6) = True
  | otherwise = False