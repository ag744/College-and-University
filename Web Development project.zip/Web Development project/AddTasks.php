<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        Add Task
    </title>
    <link rel="stylesheet" type="text/css" href="AddTasksCSS.css" />

    <h1>
        Add Task
    </h1>
</head>

<body>
    <div class="fieldsDiv">
        <form method="POST" action="database/addtask.php">

            <input type="text" placeholder="Title" id="titleID" name="title">
            <input type="text" placeholder="Description" id="descriptionID" name="description">
            Date due:
            <input type="date" placeholder="Date Due" id="dateBtn" name="date">
            Completed:
            <input type="checkbox" placeholder="Completed" id="completedID" name="completed">

            <button id="addTaskBtn" class="button" name="addBtn"  >Add Task</button>

        </form>
    </div>
    <div id="cancelBtnDiv">
        <form action="MainTasks.php">
            <button class="button cancelBtn">Cancel</button>
        </form>
    </div>
</body>

</html>