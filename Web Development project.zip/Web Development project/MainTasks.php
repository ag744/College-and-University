<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        MainTasks
    </title>
    <link rel="stylesheet" type="text/css" href="MainTasksCSS.css" />
    <h1>
        All Tasks
        <h4>
        Username
        </h4>
    </h1>
</head>

<body>
    <div id="buttonLogoutDiv">
        <form action="Login.php">
            <button class="button logoutBtn">Logout</button>
        </form>
    </div>
    <div id="buttonAddDiv">
        <form action="AddTasks.php">
            <button name="addBtn" class="button">Add Task</button>
        </form>
    </div>

    <!-- edit -->

    <div style="text-align: center" id="tableDiv">
        <form method="POST" action="Edit.php">
            <table style="width: auto;">
                <th>Task Name</th>
                <th>Description</th>
                <th>Due Date</th>
                <th>Done</th>
                <th>Edit</th>
                <?php
                    ini_set('display_errors', true);
                    error_reporting(E_ALL);
                    require "database/connect.php";
                    
                    $sql = "SELECT title,descr,dt,completed FROM tasks";

                    $results = $connect-> query($sql);

                    if(mysqli_num_rows($results) > 0){
                        while ($column = mysqli_fetch_assoc($results)){
                            $title = $column["title"];
                            $descr = $column["descr"];
                            $dt = $column["dt"];
                            $completed = $column["completed"];
                            
                            echo ("<tr><td>" . $title ."</td><td>" . $descr . "</td><td>" . $dt . "</td><td>" . $completed ."</td></tr>");
                        }
                        echo ("</table>");
                    }
                    else{
                        echo ("No Tasks");
                    }
                ?>
        </form>
    </div>

</body>

</html>