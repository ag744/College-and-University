<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register</title>
  <link rel="stylesheet" type="text/css" href="ErrorCSS.css">
  <div id="h1Div">
    <h1>Error</h1>
  </div>
</head>

<body>
CLASS AND ID = FOR STYLING 
  <div id="fieldsDiv">
    <form method="POST" action="Routes/Login.php">
        <H3>
            Error loggin in. Incorrect details.
        </H3>
      <button  id="submitBtnDiv" name="submitBtn" class="button">Login</button>
    </form>
  </div>
</body>

</html>