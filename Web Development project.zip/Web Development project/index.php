<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Register</title>
  <link rel="stylesheet" type="text/css" href="RegisterCSS.css">
  <div id="h1Div">
    <h1>Register</h1>
  </div>
</head>

<body>
  <div id="fieldsDiv">
    <form method="POST" action="database/register.php">
    
      <input placeholder="Username" type="text" name="uname" id = "uname" required/><br /><br />
      <input placeholder="Password" type="password" name="pass" id = "pass" required/><br /><br />
      <input placeholder="Email" type="text" name="email" id = "email" required/><br /><br />
      <button  id="submitBtnDiv" name="submitBtn" class="button">Submit</button>
    </form>

  </div>

  <div>
    <form action="Login.php">
      <button class="button loginBtn">Login</button>
    </form>
  </div>

</body>

</html>