<?php
        ini_set('display_errors', true);
        error_reporting(E_ALL);