<?php
    require "connect.php";

    $uname = $_POST["uname"];
    $pass = $_POST["pass"];

    $sql = "SELECT * FROM users WHERE (username='$uname' AND pass='$pass')";

    $results = mysqli_query($connect, $sql);
    $columns = mysqli_fetch_assoc($results);
    $rows = mysqli_num_rows($results);

    $username = $columns["username"];
    $passw = $columns["pass"];
    $id = $columns["id"];

    if($rows){
        if($username == $uname){
            if($passw == $pass){
                session_start();
                $_SESSION["username"] = $username;
                $_SESSION["userID"] = $id;
                header('location: ../Routes/Main.php');
            }else {
                header("Location: ../ErrorLogin.php");
        
            }
        }
    }
?>