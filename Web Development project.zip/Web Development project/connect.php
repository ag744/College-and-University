<?php

    $name_server = "emps-sql.ex.ac.uk";
    $username_db = "ag744";
    $pass = "ag744";
    $databasename = "ag744";
    
    $connect = mysqli_connect($name_server, $username_db, $pass, $databasename, 3306);

    if(!$connect){
        die ("Connection error, bye bye".mysqli_connect_error());
    }
?>