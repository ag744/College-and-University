<?php

    if(isset($_POST["addBtn"])){
        require "connect.php";

        $id = $_SESSION["id"];
        $title = $_POST["title"];
        $description = $_POST["description"];
        $date = $_POST["date"];
        $completed = $_POST["completed"];

        $sql = "INSERT INTO tasks (id, title, descr, dt, completed) VALUES ('$id','$title','$description','$date','$completed')";
        
        $stmt = mysqli_stmt_init($connect);
        mysqli_stmt_prepare($stmt, $sql);
        mysqli_stmt_execute($stmt);

        mysqli_close($connect);
        header("Location: ../MainTasks.php");
    } else {
        header("Location: ../ErrorAdd.php");
        exit();
    }
?>