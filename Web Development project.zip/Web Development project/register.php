<?php

    if(isset($_POST["submitBtn"])){

        require "connect.php";
        
        $userN = $_POST["uname"];
        $pass = $_POST["pass"];
        $email = $_POST["email"];
        
        $sql = "INSERT INTO users (username,pass,email) VALUES ('$userN','$pass','$email')";
        
        $stmt = mysqli_stmt_init($connect);
        mysqli_stmt_prepare($stmt, $sql);
        mysqli_stmt_execute($stmt);

        header("Location: ../Routes/Login.php");
    } else {
        header("Location: ../Routes/index.php");
        exit();
    }