package Main;

import java.util.Random;

/**
 * Class to store all data about a player.
 * @author 690020366
 */
public class Player {

    private Card card;
    private Random rand = new Random();

    private String name;
    private int preference;

    /**
     * Constructor to make the player's hand and provide a name for the player
     * @param playerNum
     */
    public Player(int playerNum) {
        name = "Player" + String.valueOf(playerNum);
        card = new Card();
    }

    /**
     * receives and returns a card from the initial round robin rotation 
     * @param player player to receive the card
     * @param card card to be received
     * @param pos position at which the card is received
     * @return returns the card
     */
    public int receiveCard(Player player, String card, int pos) {
        int temp;
        int[] tempArray;

        temp = Integer.parseInt(card);

        tempArray = player.card.getHand();
        tempArray[pos] = temp;

//        this.card.printHand();

        return temp;
    }

    /**
     * gets the current player's hand
     * @return returns the hand
     */
    public int[] getHand() {
        return card.getHand();
    }

    /**
     * gets the current player's preference
     * @return returns the preference of the player
     */
    public int getPreference() {
        return preference;
    }

}
