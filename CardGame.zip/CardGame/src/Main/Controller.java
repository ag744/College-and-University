package Main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author 690020366
 */
public class Controller implements Runnable {

    private CardGame cardGame;

    Thread[] threads = new Thread[CardGame.playerCount + 1];//used to store all threads

    private volatile boolean running = true;//used to have a condition between all threads

    /**
     * used to store all player objects and their values
     */
    public final ArrayList<Player> players = new ArrayList<>();

    /**
     * used to store all CardDeck objects and their values
     */
    public final ArrayList<CardDeck> decks = new ArrayList<>();

    /**
     * constructor used to instantiate all Player and CardDeck objects
     *
     * @param cardGame
     */
    public Controller(CardGame cardGame) {
        this.cardGame = cardGame;

        for (int i = 1; i <= CardGame.playerCount; i++) {
            players.add(new Player(i));//initialise all players
        }
        for (int i = 1; i <= CardGame.playerCount; i++) {
            decks.add(new CardDeck(i));//initialise all decks
        }

        roundRobinPlayers(cardGame);
        cardGame.setDecks(roundRobinDecks(cardGame));

        start();
    }

    @Override
    public void run() {
        //game functionality-----------------------
        try {
            //initial conditions / round 1
            String threadName = Thread.currentThread().getName();

            int index = Integer.parseInt(threadName.substring(6));//used to get the card to discard and the new card for the specific player
            int[] startHand = players.get(index - 1).getHand();//used to check if the player's hand is a winning hand
            boolean isWon = checkWin(startHand);//boolean to state whether the player's hand is a winning one or not

            String filepath = "players/" + threadName + "/logs";//filepath to make directories
            String filename = "players/" + threadName + "/logs/log.txt";//filepath to make text files and write into them

            writeLogStart(threadName, filepath, filename, startHand);//write the starting log for every player

            if (isWon) {//if a player has a winning hand notify all other threads
                synchronized (this) {
                    writeLogInstantWin(threadName, filename);//write log to state the instant win
                    running = false;
                }
            }

            int preference = Integer.parseInt(Thread.currentThread().getName().substring(6));//preference for each player is their number(e.g. Player1 = 1, Player25 = 25)
            int useless = 0;//card which is discarded or not the player's preference
            int newCard = 0;//new card acquired from deck to the player's right
            int[] tempHand = startHand;//used to overwrite the hand of the player each round

            while (running) {//round 2 and onwards
                //one turn of the player is one loop of this while

                useless = getUseless(tempHand, preference);//get the useless/non preferenced card

                int getDeckIndex;//used to provide index for the deck to the left of the player as we had some minor issues with this
                int giveDeckIndex;//used to provide index for the deck to the right of the player

                if (index == CardGame.playerCount) {//loop back around to the first player if the current thread is the last player
                    getDeckIndex = index - 1;
                    giveDeckIndex = 0;
                } else {
                    getDeckIndex = index - 1;
                    giveDeckIndex = index;
                }

                newCard = getCard(getDeckIndex);//get the player a new card from the left deck
                giveCard(useless, giveDeckIndex);//give the useless card from the player's hand into the right deck

                tempHand = replaceHand(tempHand, newCard, useless);//rewrite the temp hand with a replacement including the new card and without the useless card

                writeLogMid(threadName, filename, useless, newCard, getDeckIndex + 1, giveDeckIndex + 1, tempHand);//write the logs for all threads in their respective files

                isWon = checkWin(tempHand);//check if the user has won

                if (isWon) {//if a player has a winning hand notify all other threads
                    synchronized (this) {
                        writeLogFinal(threadName, filename, tempHand);//log all players to state the winner
                        System.out.println(threadName + " wins");
                        running = false;
                    }
                }
                Thread.sleep(5);//wait 0.05 seconds between each round
            }

            writeDeckLog(decks, decks.get(Integer.parseInt(threadName.substring(6)) - 1).getDeckNum());//log all deck final values
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * initialisation of threads
     */
    public void start() {

        for (int i = 1; i <= CardGame.playerCount; i++) {
            threads[i] = new Thread(this, "Player" + i);
            threads[i].start();
        }
        try {
            for (int i = 1; i <= CardGame.playerCount; i++) {
                threads[i].join();
            }
        } catch (Exception e) {
        }
    }

    /**
     * distribute the cards to all players one by one in a round robin rotation
     *
     * @param cardGame used to get the pack
     */
    private void roundRobinPlayers(CardGame cardGame) {
        String[] mainDeck = cardGame.getPack();

        for (int i = 0; i < 4; i++) {//each player needs 4 cards
            for (int j = 0; j < players.size(); j++) {//loop through all players giving them a card
                Player tempObject = players.get(j);
                tempObject.receiveCard(tempObject, mainDeck[(i * players.size()) + j], i);
            }
        }
    }

    /**
     * distribute the cards to all decks one by one in a round robin rotation
     *
     * @param cardGame used to get the pack
     * @return returns all decks made from the pack
     */
    private int[][] roundRobinDecks(CardGame cardGame) {
        int amountLeft = CardGame.playerCount * 4;//amount of cards left after distribution of player hands
        int[][] allDecks = new int[CardGame.playerCount][4];
        String[] mainDeck = cardGame.getPack();

        String[] temp = new String[mainDeck.length - amountLeft];

        for (int i = 0; i < temp.length; i++) {
            temp[i] = mainDeck[amountLeft + i];
        }

        for (int i = 0; i < 4; i++) {//each deck needs 4 cards // columns
            for (int j = 0; j < CardGame.playerCount; j++) { // rows
                allDecks[j][i] = Integer.parseInt(temp[(CardGame.playerCount * i) + j]);
                CardDeck tempObject = decks.get(j);
                tempObject.receiveCard(tempObject, temp[(CardGame.playerCount * i) + j], i);
            }
        }

        cardGame.setDecks(allDecks);

        return allDecks;
    }

    /**
     * get the card from the left deck of the player
     *
     * @param index card index to be got
     * @return return the card at index
     */
    private int getCard(int index) {
        int card;

        card = decks.get(index).getHand()[3];

        return card;
    }

    /**
     * give the card to the right deck of player
     *
     * @param card card to be given
     * @param index index of deck to give the card to
     */
    private void giveCard(int card, int index) {
        decks.get(index).setCard(card);
    }

    /**
     * replaces the useless card in the current hand with the new card
     *
     * @param previousHand previous hand
     * @param newCard card to be replaced by
     * @param uselessCard card to be replaced
     * @return returns the new/modified hand
     */
    private int[] replaceHand(int[] previousHand, int newCard, int uselessCard) {
        int[] newHand = new int[4];
        boolean done = false;

        for (int i = 0; i < 4; i++) {
            if (!done) {
                if (previousHand[i] == uselessCard) {
                    newHand[i] = newCard;
                    done = true;
                    continue;//we only want this to happen once in case of duplications
                }
            }
            newHand[i] = previousHand[i];
        }

        return newHand;
    }

    /**
     * get the useless card/ non preferenced card
     *
     * @param hand hand to determine the useless card
     * @param preference preference of player
     * @return returns the useless card
     */
    private int getUseless(int[] hand, int preference) {
        int uselessCard = 0;
        ArrayList<Integer> uselessPos = new ArrayList<>();
        Random r = new Random();

        for (int i = 0; i < 4; i++) {
            if (hand[i] != preference) {//get the non-preferenced card from player
                uselessPos.add(i);
            }
        }
        int temp;
        try {
            temp = r.nextInt(uselessPos.size());
        } catch (Exception e) {
            temp = 0;
        }
        uselessCard = hand[uselessPos.get(temp)];//randomise between all non-preferenced cards

        return uselessCard;
    }

    /**
     * check if the hand is a winning hand
     *
     * @param tempHand hand to be checked
     * @return returns true if all elements are the same, false otherwise
     */
    private boolean checkWin(int[] tempHand) {
        boolean win = false;

        if ((tempHand[0] == tempHand[1]) && (tempHand[1] == tempHand[2]) && (tempHand[2] == tempHand[3])) {
            win = true;
        }

        return win;
    }

    /**
     * write the logs at the start of the game, make directories for each player
     *
     * @param playerName player to be logged
     * @param filepath file path for directories to be created
     * @param filename file name to be written into after the directories have
     * been created
     * @param playerInitialHand starting hand of player
     */
    private void writeLogStart(String playerName, String filepath, String filename, int[] playerInitialHand) {

        new File(filepath).mkdirs();//make folders

        int initialCard1 = playerInitialHand[0];
        int initialCard2 = playerInitialHand[1];
        int initialCard3 = playerInitialHand[2];
        int initialCard4 = playerInitialHand[3];

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename));

            writer.write(playerName + " initial hand " + initialCard1 + " " + initialCard2 + " " + initialCard3 + " " + initialCard4 + System.lineSeparator());

            writer.close();
        } catch (Exception e) {
        }
    }

    /**
     * write logs for player if they have instantly won from the first round
     *
     * @param playerName player to be logged
     * @param filename file name/path of the log file
     */
    private void writeLogInstantWin(String playerName, String filename) {

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filename));

            writer.write(playerName + " wins" + System.lineSeparator());

            writer.close();
        } catch (Exception e) {
        }
    }

    /**
     * write logs for each player after each round
     *
     * @param playerName player to be logged
     * @param filepath file path of the log file
     * @param useless useless card for this round
     * @param newCard new card for this round
     * @param getDeckNum deck number for where the new card was gotten from
     * @param giveDeckNum deck number for where the useless card was discarded
     * to
     * @param playerCurrentHand player's current hand
     */
    private void writeLogMid(String playerName, String filepath, int useless, int newCard, int getDeckNum, int giveDeckNum, int[] playerCurrentHand) {

        int currentCard1 = playerCurrentHand[0];
        int currentCard2 = playerCurrentHand[1];
        int currentCard3 = playerCurrentHand[2];
        int currentCard4 = playerCurrentHand[3];

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filepath, true));

            writer.write(playerName + " draws a " + newCard + " from deck " + getDeckNum + System.lineSeparator());
            writer.write(playerName + " discards a " + useless + " to deck " + giveDeckNum + System.lineSeparator());
            writer.write(playerName + " current hand " + currentCard1 + " " + currentCard2 + " " + currentCard3 + " " + currentCard4 + System.lineSeparator());

            writer.close();
        } catch (Exception e) {
        }
    }

    /**
     * write the winner in every player's log files. this method should be
     * executed after the winner wins.
     *
     * @param playerName player to be logged (winner)
     * @param filepath file path to be written into for the winner only
     * @param playerFinalHand winner hand
     */
    private void writeLogFinal(String playerName, String filepath, int[] playerFinalHand) {

        int finalCard1 = playerFinalHand[0];
        int finalCard2 = playerFinalHand[1];
        int finalCard3 = playerFinalHand[2];
        int finalCard4 = playerFinalHand[3];

        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filepath, true));

            for (int i = 1; i <= CardGame.playerCount; i++) {
                String newFilepath = "players/Player" + i + "/logs/log.txt";

                BufferedWriter writer2 = new BufferedWriter(new FileWriter(newFilepath, true));
                BufferedWriter writer3 = new BufferedWriter(new FileWriter(newFilepath, true));

                if (i != Integer.parseInt(playerName.substring(6))) {
                    writer3.write(playerName + " has informed Player" + i + " that " + playerName + " has won" + System.lineSeparator());
                }

                writer3.close();
                writer2.close();
            }
            writer.write(playerName + " wins" + System.lineSeparator());
            writer.write(playerName + " exits" + System.lineSeparator());
            writer.write(playerName + " final hand " + finalCard1 + " " + finalCard2 + " " + finalCard3 + " " + finalCard4 + System.lineSeparator());

            writer.close();
        } catch (Exception e) {
        }
    }

    /**
     * write the logs for all decks and make directories for each deck
     *
     * @param allDecks list containing all small decks
     * @param deckNum deck number of the deck to be logged
     */
    private void writeDeckLog(ArrayList<CardDeck> allDecks, int deckNum) {

        new File("decks/deck" + deckNum + "/logs").mkdirs();

        try {
            for (int i = 1; i <= CardGame.playerCount; i++) {

                String filename = "decks/deck" + i + "/logs/log.txt";

                CardDeck tempDeck = allDecks.get(i - 1);

                int deckCard1 = tempDeck.getHand()[0];
                int deckCard2 = tempDeck.getHand()[1];
                int deckCard3 = tempDeck.getHand()[2];
                int deckCard4 = tempDeck.getHand()[3];

                BufferedWriter writer = new BufferedWriter(new FileWriter(filename));

                writer.write("deck" + i + " contents: " + deckCard1 + " " + deckCard2 + " " + deckCard3 + " " + deckCard4 + System.lineSeparator());

                writer.close();
            }
        } catch (Exception e) {
        }
    }
}
