package Main;

import java.util.Arrays;

/**
 * Class used to store a hand.
 * A hand is both the 4 cards for a player and the 4 cards for a small deck
 * @author 690020366
 */
public class Card {

    private int[] hand = new int[4];

    /**
     * prints this instance's hand
     */
    public void printHand() {
        System.out.println(Arrays.toString(hand));
    }

    /**
     * Gets this instance's hand
     * @return this instance's hand
     */
    public int[] getHand() {
        return hand;
    }
}
