package Main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Random;
import java.util.Scanner;

/**
 * Main class used to run the program and get user input for amount of players
 * and pack file name
 *
 * @author 690020366
 */
public class CardGame {

    /**
     * used to store the user input for amount of players
     */
    public static int playerCount;

    private String filename;//stores the filename inputted by user
    private String[] pack = {};//stores the pack of cards
    private int[][] allDecks = new int[CardGame.playerCount][4];//used to locally store all the decks

    /**
     * constructor used to start the program without the need of making
     * everything static
     */
    public CardGame() {
        playerCount = getPlayerCount();//get user input for amount of players
        writeFile("test.txt", playerCount);
        this.pack = readFile();//get user input for pack file location

        new Controller(this);//initialise all player and deck objects
    }

    /**
     * method to get input from user on location of pack file
     *
     * @return returns the pack file as a String[] if valid path
     */
    private String[] readFile() {
        String[] pack = new String[playerCount * 8];
        getFileName();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));

            String line;

            int i = 0;
            while ((line = reader.readLine()) != null) {
                pack[i] = line;
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return pack;
    }

    /**
     * write a random sequence of numbers (random amount up to playerCount).
     * amount of lines = 8 * playerCount
     *
     * @param filename file name to be written to, creates a new file if file
     * does not exist
     * @param playerCount amount of players to consider
     */
    private void writeFile(String filename, int playerCount) {
        File file = new File(filename);
        Random rand = new Random();

        try {
            FileWriter writer = new FileWriter(filename);
            for (int i = 0; i < playerCount * 8; i++) {
                int row = rand.nextInt(playerCount) + 1;

                String temp = String.valueOf(row);

                writer.write(temp);
                writer.write(System.lineSeparator());
            }
            writer.close();
        } catch (Exception e) {
        }
    }

    /**
     * get the amount of players playing the game currently
     * @return returns the amount of players currently playing
     */
    private int getPlayerCount() {
        int playerCount;

        Scanner sc = new Scanner(System.in);

        System.out.println("Please input the amount of players to play: ");
        playerCount = Integer.parseInt(sc.nextLine());

        return playerCount;
    }

    /**
     * get user input of a valid pack file, will continuously ask for user input
     * if user inputs a non-existant file
     */
    private void getFileName() {
        String fileName = "";
        boolean validFile = false;

        Scanner sc = new Scanner(System.in);

        System.out.println("Please input the pack file name ");

        while (!validFile) {
            fileName = sc.nextLine();

            this.filename = fileName;

            try {
                FileReader reader = new FileReader(fileName);
                validFile = true;
            } catch (Exception e) {
                System.out.println("Please enter a valid file name: ");
                validFile = false;
            }
        }
    }

    /**
     * method to return the pack
     *
     * @return returns the pack
     */
    public String[] getPack() {
        return this.pack;
    }

    /**
     * method to get all decks, players and smaller decks
     *
     * @return
     */
    public int[][] getDecks() {
        return this.allDecks;
    }

    /**
     * set all decks to the parameter array
     *
     * @param array input array
     */
    public void setDecks(int[][] array) {
        this.allDecks = array;
    }

    /**
     * main method initialises a new CardGame constructor, starting the game
     *
     * @param args
     */
    public static void main(String[] args) {
        new CardGame();
    }

}
