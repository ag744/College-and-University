package Main;

/**
 * Class to store all small decks
 *
 * @author 690020366
 */
public class CardDeck {

    private CardGame cardGame;
    private Card card;

    private int deckNum;

    /**
     * constructor to provide a deck number to each deck and make a hand for the
     * deck
     *
     * @param deckNum
     */
    public CardDeck(int deckNum) {
        this.deckNum = deckNum;
        card = new Card();
    }

    /**
     * receives and returns a card from the initial round robin rotation
     *
     * @param cardDeck small deck to input into
     * @param card card to be received
     * @param pos position at which the card is received
     * @return returns the card
     */
    public int receiveCard(CardDeck cardDeck, String card, int pos) {
        int temp;
        int[] tempArray;

        temp = Integer.parseInt(card);

        tempArray = cardDeck.card.getHand();
        tempArray[pos] = temp;

//        this.card.printHand();
        return temp;
    }

    /**
     * get the 4 cards contained within this instance
     *
     * @return returns the hand (4 cards)
     */
    public int[] getHand() {
        return this.card.getHand();
    }

    /**
     * inputs the card on the bottom of the deck
     *
     * @param card sets the first element to be the input
     */
    public void setCard(int card) {

        this.card.getHand()[3] = this.card.getHand()[2];
        this.card.getHand()[2] = this.card.getHand()[1];
        this.card.getHand()[1] = this.card.getHand()[0];

        this.card.getHand()[0] = card;
    }

    /**
     * get this instance's deck number
     * @return small deck number
     */
    public int getDeckNum() {
        return this.deckNum;
    }
}
