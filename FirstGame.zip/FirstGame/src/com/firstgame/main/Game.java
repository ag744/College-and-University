
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author Angel
 */
public class Game extends Canvas implements Runnable {
    //makes the game using Canvas class

    public static final int WIDTH = 800;// window size initialisation
    public static final int HEIGHT = 600;

    private Thread thread; //creation of an instance of class Thread
    public boolean running = false; //variable used to return a value saying if the thread is running or not

    public static boolean paused = false;

    private Random r;
    private Handler handler;
    private HUD hud;
    private Spawn spawner;
    private Menu menu;
    private Player player;
    private Shop shop;

    public enum STATE {
        Menu,
        Help,
        End,
        Shop,
        Login,
        Register,
        Select,
        Game;
    }

    public STATE gameState = STATE.Menu;

    public static BufferedImage sprite_sheet;

    public int diff = 0;
    //0 = normal
    //1 = hard

    public Game() {

        BufferedImageLoader loader = new BufferedImageLoader();
        sprite_sheet = loader.loadImage("/sprite_sheet.png");//loads the spritesheet/image for enemies and player

        handler = new Handler();
        hud = new HUD();
        shop = new Shop(handler, hud);
        menu = new Menu(this, handler, hud);
        this.addKeyListener(new KeyInput(handler, this));
        this.addMouseListener(menu);

        new Window(WIDTH, HEIGHT, "First Game", this); //creation of window for game

        spawner = new Spawn(handler, hud, this);
        r = new Random();//initialises r

        if (gameState == STATE.End) {
            handler.removeObject(player);
        }// removes the player object when the game has ended

    }

    public synchronized void start() {
        //procedure to start the thread
        thread = new Thread(this); //creates a new instance of class Thread and runs it on "this" class
        thread.start();
        running = true;
    }

    public synchronized void stop() {
        //procedure to stop the thread
        try {
            //use of try catch to take care of errors
            thread.join();//stops thread
            running = false;

        } catch (Exception e) {
            e.printStackTrace();// prints off execption statement to the console
        }
    }

    public void run() {
        //method to start the game
        this.requestFocus();//requests focus of window automatically
        long lastTime = System.nanoTime();//takes the current time from the system clock niin nano seconds
        final double amountOfTicks = 60.0; //60 FPS
        double ns = 1000000000 / amountOfTicks;//1 billion is 1 second in nanoseconds
        double delta = 0;//variable used to catch up on time
        //int updates = 0;//ticks the game is//debug
        //int frames = 0;//frames per second the game is running at//debug
        //long timer = System.currentTimeMillis();//takes current time of system on milliseconds

        while (running) {//game loop
            long now = System.nanoTime();//takes the current system clock time in nanoseconds
            delta += (now - lastTime) / ns;//uses delta to see the difference and catch up
            lastTime = now;//setting last time to equal the time now
            if (delta >= 1) {
                tick();
                //updates++;//debug
                delta--;
            }
            render();
            //frames++;//debug

            /*if (System.currentTimeMillis() - timer > 1000) {
                timer += 1000;//adds 1000 so that it runs this code every second
                //(1000 milliseconds are 1 second)
                //System.out.println("Frames " + frames + "  |  Ticks " + updates);//prints off FPS in the 
                //console window
                //frames = 0;//resets frames and updates so that//debug  
                //updates = 0;//they don't add up with the previous values
            }*/
        }
        stop();
    }

    private void tick() {
        //procedure to measure the amount of updates 

        if (gameState == STATE.Game) {

            if (paused == false) {
                hud.tick();
                spawner.tick();
                handler.tick();

                if (HUD.HEALTH <= 0) {
                    gameState = STATE.End;
                    HUD.HEALTH = 100;
                    handler.clearEnemies();
                }
            }
        }
        if (gameState == STATE.Menu || gameState == STATE.End || gameState == STATE.Select) {
            menu.tick();
            handler.tick();

        }
        if (gameState == STATE.Menu) {
            hud.setLevel(0);
            hud.setScore(0);
        }

    }

    private void render() {
        //procedure to measure the amount of frames

        BufferStrategy bs = this.getBufferStrategy();//makes an instance of class BufferStrategy and returns 
        //null if one is not created yet

        if (bs == null) {
            this.createBufferStrategy(3);//3 refers to how many buffers are created
            return;//retuns the value of createBufferStratedy to "bs" to avoid it being null
        }

        Graphics g = bs.getDrawGraphics();//creates a variable of type Graphics which will use 
        //the getDrawGraphics method to produce graphics inside the JFrame

        g.setColor(Color.black);//sets the background colour to be filled with to black
        g.fillRect(0, 0, WIDTH, HEIGHT);//fills the screen with the specified colour

        if (gameState == STATE.Game) {
            handler.render(g);
            hud.render(g);

        } else if (gameState == STATE.Menu || gameState == STATE.Help || gameState == STATE.End || gameState == STATE.Select) {
            handler.render(g);
            menu.render(g);
        }
        if (gameState == STATE.Shop) {
            shop.render(g);
        }
        if (paused == true) {
            Font fnt = new Font("arial", 4, 22);
            g.setFont(fnt);
            g.setColor(Color.white);
            g.drawString("Paused", 690, 40);
        }

        g.dispose();//disposes of variable 
        bs.show();//shows graphics
    }

    public static float clamp(float var, float min, float max) {
        //function to keep a changing value within limits specified

        if (var >= max) {
            return var = max;
        }
        if (var <= min) {
            return var = min;
        } else {
            return var;
        }
    }

    public static void main(String args[]) {
        new Game();
    }
}
