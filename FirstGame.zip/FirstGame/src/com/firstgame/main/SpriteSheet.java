/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.image.BufferedImage;

/**
 *
 * @author Angel
 */
public class SpriteSheet {
    //crop the image to the images we want
    private BufferedImage sprite;
    
    public SpriteSheet(BufferedImage ss){
        this.sprite = ss;
        //whatever is put into the class is converted to a sprite
    }
    
    public BufferedImage takeImage(int column, int row, int width, int heigth){
        BufferedImage img = sprite.getSubimage((row*32) - 32, (column*32) - 32, width, heigth);
        return img;
    }
    
}
