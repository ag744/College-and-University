/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Angel
 */
public class PowerupHP extends GameObject {

    private Handler handler;
    private Player player;
    private BufferedImage health_image;

    public PowerupHP(int x, int y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

        velX = 0;
        velY = 0;
        
        SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);
        
        health_image = ss.takeImage(2, 1, 16, 16);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 8, 8);//creattion of hitboxes using Rectangle
    }

    public void tick() {
        
    }

    public void render(Graphics g) {
        
        g.drawImage(health_image, (int)x, (int)y, null);
        
//        g.setColor(Color.white);//setting of enemy colour as red
//        g.fillRect((int)x, (int)y, 8, 8);//setting of enemy size of object to 16x16 pixels
    }

}
