/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Angel
 */
public class SmartEnemy extends GameObject {

    private Handler handler;
    private Player player;
    private BufferedImage enemy_image;

    public SmartEnemy(float x, float y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

        SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);

        enemy_image = ss.takeImage(1, 4, 16, 16);

        for (GameObject obj : handler.object) {
            if (obj instanceof Player) {
                this.player = (Player) obj;
            }
        }
//        for (int i = 0; i < handler.object.size(); i++) {
//            if (handler.object.get(i).getID() == ID.Player) {
//                player = handler.object.get(i);
//                this.player
//            }
//        }

    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 16, 16);//creattion of hitboxes using Rectangle
    }

    public void tick() {
        x += velX;
        y += velY;
        //System.out.println(x + "|" + y + "debug 1");

        float diffX = x - player.getX() - 8;
        float diffY = y - player.getY() - 8;

        //System.out.println(diffX + "|" + diffY + "debug 2");
        float distance = (float) Math.sqrt(((x - player.getX()) * (x - player.getX())) + ((y - player.getY()) * (y - player.getY())));

        //System.out.println(distance + "debug 3");
        velX = (float) (-1 / distance) * diffX;
        velY = (float) (-1 / distance) * diffY;

        //System.out.println(velX + "|" + velY + "debug 4");
        //handler.addObject(new Trail((int) x, (int) y, ID.Trail, Color.green, 16, 16, 0.03f, handler));//addition of trail
    }

    public void render(Graphics g) {

        g.drawImage(enemy_image, (int) x, (int) y, null);

//        g.setColor(Color.green);//setting of enemy colour as red
//        g.fillRect((int) x, (int) y, 16, 16);//setting of enemy size of object to 16x16 pixels
    }

}
