/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import com.firstgame.main.Game.STATE;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Random;

/**
 *
 * @author Angel
 */
public class Menu extends MouseAdapter {

    private Game game;
    private HUD hud;
    private Handler handler;
    private Random r = new Random();

    public Menu(Game game, Handler handler, HUD hud) {
        this.game = game;
        this.hud = hud;
        this.handler = handler;
    }

    public void mousePressed(MouseEvent e) {

        int mx = e.getX();
        int my = e.getY();

        //back button for help
        if (game.gameState == STATE.Help) {
            if (mouseOver(mx, my, 300, 400, 200, 50)) {
                game.gameState = STATE.Menu;
                return;
            }
        }

        if (game.gameState == STATE.Menu) {
            //play button
            if (mouseOver(mx, my, 300, 250, 200, 50)) {
                game.gameState = STATE.Select;
                return;
            }

            //help button
            if (mouseOver(mx, my, 300, 325, 200, 50)) {
                game.gameState = STATE.Help;
            }

            //quit button
            if (mouseOver(mx, my, 300, 400, 200, 50)) {
                System.exit(0);
            }
        }

        if (game.gameState == STATE.End) {
            //try again button
            if (mouseOver(mx, my, 300, 325, 200, 50)) {
                game.gameState = STATE.Menu;
            }
            //back button
            if (mouseOver(mx, my, 300, 400, 200, 50)) {
                game.gameState = STATE.Menu;
            }
        }

        if (game.gameState == STATE.Select) {
            //normal button
            if (mouseOver(mx, my, 300, 250, 200, 50)) {
                game.gameState = STATE.Game;
                handler.addObject(new Player(Game.WIDTH / 2 - 32, Game.HEIGHT / 2 - 32, ID.Player, handler));//adds a player object
                handler.addObject(new BasicEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.BasicEnemy, handler));

                game.diff = 0;
            }
            //hard button
            if (mouseOver(mx, my, 300, 325, 200, 50)) {
                game.gameState = STATE.Game;
                handler.addObject(new Player(Game.WIDTH / 2 - 32, Game.HEIGHT / 2 - 32, ID.Player, handler));//adds a player object
                handler.addObject(new HardEnemy(r.nextInt(Game.WIDTH), r.nextInt(Game.HEIGHT), ID.HardEnemy, handler));

                game.diff = 1;
            }

            //back button
            if (mouseOver(mx, my, 300, 400, 200, 50)) {

                game.gameState = STATE.Menu;
                return;

            }
        }

    }

    public void mouseReleased(MouseEvent e) {

    }

    private boolean mouseOver(int mx, int my, int x, int y, int width, int height) {
        if (mx > x && mx < x + width) {
            if (my > y && my < y + height) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public void tick() {

    }

    public void render(Graphics g) {
        if (game.gameState == STATE.Help) {
            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);
            Font fnt3 = new Font("arial", 1, 20);

            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Help", 331, 50);

            g.setFont(fnt3);
            g.drawString("Use the arrow keys to move the player", 220, 200);
            g.drawString("Dodge enemies and have fun", 260, 250);

            g.setFont(fnt2);
            g.drawRect(300, 400, 200, 50);
            g.drawString("Back", 368, 435);
        }
        if (game.gameState == STATE.Menu) {
            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);

            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Menu", 331, 50);

            g.setFont(fnt2);
            g.drawRect(300, 250, 200, 50);
            g.drawString("Play", 368, 283);

            g.drawRect(300, 325, 200, 50);
            g.drawString("Help", 368, 360);

            g.drawRect(300, 400, 200, 50);
            g.drawString("Quit", 368, 435);
        }

        if (game.gameState == STATE.End) {
            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);
            Font fnt3 = new Font("arial", 1, 20);

            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Game Over", 262, 50);

            g.setFont(fnt3);
            g.drawString("You died with a score of " + hud.getScore(), 262, 200);
            g.drawString("and on Level " + hud.getLevel(), 320, 250);

            g.setFont(fnt2);
            g.drawRect(300, 325, 200, 50);
            g.drawString("Try Again", 335, 360);

            g.drawRect(300, 400, 200, 50);
            g.drawString("Menu", 362, 435);

        }
        if (game.gameState == STATE.Select) {
            Font fnt = new Font("arial", 1, 50);
            Font fnt2 = new Font("arial", 1, 30);

            g.setColor(Color.white);
            g.setFont(fnt);
            g.drawString("Select Difficulty", 220, 50);

            g.setFont(fnt2);
            g.drawRect(300, 250, 200, 50);
            g.drawString("Normal", 350, 283);

            g.drawRect(300, 325, 200, 50);
            g.drawString("Hard", 368, 360);

            g.drawRect(300, 400, 200, 50);
            g.drawString("Back", 368, 435);
        }
        
    }

}
