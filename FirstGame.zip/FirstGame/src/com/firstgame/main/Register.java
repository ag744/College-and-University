/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;

/**
 *
 * @author Angel
 */
public class Register extends MouseAdapter {

    public static boolean lengthC(int reqLength, int text) {
        //method of validating for length of data input by user
        return text == reqLength;
    }

    public static boolean presenceC(String present) {
        //method for validating for presence of data
        return present != null;
    }

    public static boolean rangeC(int value, int min, int max) {
        return (value < max && value > min);
    }

    public static boolean typeCint(String num) {
        try {
            Integer.parseInt(num);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    public static boolean typeCstr(String str) {
        return (str.equals(String.valueOf(str)));
    }

    public static boolean typeCboo(String boo) {
        return boo.equals("true");
    }

    public void render(Graphics g) {
        Font fnt = new Font("arial", 1, 50);
        Font fnt2 = new Font("arial", 1, 30);

        g.setColor(Color.white);
        g.setFont(fnt);
        g.drawString("Login", 331, 50);

        g.drawRect(0, 0, 0, 0);
    }
}
