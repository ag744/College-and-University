/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.event.MouseAdapter;
import java.io.File;
import java.util.Scanner;

/**
 *
 * @author Angel
 */
public class Login extends MouseAdapter{
    
    private static Scanner sc;
    
    public static void loginVerify(String username, String password, File file){
        
        boolean found = false;
        String tempUsername = "";
        String tempPassword = "";
        
        try {
            sc = new Scanner(file);
            sc.useDelimiter("[,\n]");
            
            while(sc.hasNext() && !found){
                tempUsername = sc.next();
                tempPassword = sc.next();
                
                if(tempUsername.trim().equals(username.trim()) && tempPassword.trim().equals(password.trim())){
                    found = true;
                }
            }
            sc.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
    }
    
}
