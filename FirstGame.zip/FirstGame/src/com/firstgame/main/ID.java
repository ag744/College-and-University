/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

/**
 *
 * @author Angel
 */
public enum ID {
    Player(), BasicEnemy(),BossEnemy(),FastEnemy(),SmartEnemy(),HardEnemy(),PowerupHP(),Trail();//creates two enums one as player and one as an enemy
    
}
