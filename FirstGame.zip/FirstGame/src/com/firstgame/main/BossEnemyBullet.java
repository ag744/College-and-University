/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author Angel
 */
public class BossEnemyBullet extends GameObject {

    private Handler handler;
    Random r = new Random();

    public BossEnemyBullet(int x, int y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

        velX = r.nextInt(5 - -5) + -5;//random number from -5 to +5
        velY = 5;
    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 16, 16);//creattion of hitboxes using Rectangle
    }

    public void tick() {
        x += velX;
        y += velY;
        
        if (y >= Game.HEIGHT) {
            handler.removeObject(this);
        }
        handler.addObject(new Trail((int) x, (int) y, ID.Trail, Color.red, 16, 16, 0.03f, handler));//addition of enemy trail

    }

    public void render(Graphics g) {
        g.setColor(Color.red);//setting of enemy colour as red
        g.fillRect((int) x, (int) y, 16, 16);//setting of enemy size of object to 16x16 pixels
    }

}
