/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author Angel
 */
public abstract class GameObject {
    //refers to every object in the game

    protected float x;//protected - can only be accessed by which object inherits the GameObject
    protected float y;//coordinates of objects
    protected ID id;
    protected float velX;//speed in x
    protected float velY;//speed in y

    public GameObject(float x, float y, ID id) {
        //whatevet is set as parameters is the position of the object
        this.x = x;//sets protected value of x to the parameter value
        this.y = y;//sets protected value of y to the parameter value
        this.id = id;

    }

    public abstract void tick();//used in Player class

    public abstract void render(Graphics g);

    public abstract Rectangle getBounds();

//getters and setters for x,y and id values
//sets the protected value to the value given as parameters
    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public ID getID() {
        return id;
    }

    public void setID(ID id) {
        this.id = id;
    }

    public void setVelX(int velX) {
        this.velX = velX;
    }

    public void setVelY(int velY) {
        this.velY = velY;
    }

}
