/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import com.firstgame.main.Game.STATE;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Angel
 */
public class HUD {

    private Game game;
    private HUD hud;

    public static int HEALTH = 100;//standard health value

    private int greenValue = 255;

    private int score = 0;
    private int level = 1;

    public void tick() {
        HEALTH = (int) Game.clamp(HEALTH, 0, 100);//clamps the health so that it cannot go beyond 100 or below it

        greenValue = (int) Game.clamp(greenValue, 0, 255);//transitioning of green to red of health bar
        greenValue = HEALTH * 2;

        score++;
        

    }

    public void render(Graphics g) {

        g.setColor(Color.gray);//gray box to contain health
        g.fillRect(15, 15, 200, 32);

        g.setColor(new Color(75, greenValue, 0));//green box indicating the amount of health left
        g.fillRect(15, 15, HEALTH * 2, 32);

        g.setColor(Color.white);//white rectangle serving as an outline of the health box
        g.drawRect(15, 15, 200, 32);

        g.drawString("Score " + score, 15, 64);
        g.drawString("Level " + level, 15, 80);
        g.drawString("Space for Shop", 15, 96);
    }

    public int getScore() {
        return score;
    }

    public int getLevel() {
        return level;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public void setLevel(int level) {
        this.level = level;
    }

}
