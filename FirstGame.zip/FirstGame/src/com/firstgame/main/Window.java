/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JFrame;

/**
 *
 * @author Angel
 */
public class Window extends Canvas {
    //class which makes the frame with specified size and propeties

    public Window(int width, int height, String title, Game game) {
        //method taking a width, height and title of the frame
        JFrame frame = new JFrame(title);//makes a JFrame to make the frame of the game

        frame.setPreferredSize(new Dimension(width, height));//sets the size of the frame
        frame.setMaximumSize(new Dimension(width, height));//sets the max size of the frame
        frame.setMinimumSize(new Dimension(width, height));//sets the min size of the frame

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//makes the "X" button on the top right the exit function
        frame.setResizable(false);//makes the frame not resizable
        frame.setBackground(Color.BLACK);//sets the background colour
        frame.setLocationRelativeTo(null);//makes the frame appear relative to the centre(null) of the screen
        frame.add(game);//adds instance of Game class into Window class
        frame.setVisible(true);//makes the frame visable
        game.start();//starts Game class

    }
}
