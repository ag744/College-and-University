/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Angel
 */
public class FastEnemy extends GameObject {

    private Handler handler;
    private BufferedImage enemy_image;

    public FastEnemy(float x, float y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

        velX = 5;
        velY = 12;
        
        SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);
        
        enemy_image = ss.takeImage(1, 3, 16, 16);
    }

    public Rectangle getBounds() {
        return new Rectangle((int)x, (int)y, 16, 16);//creattion of hitboxes using Rectangle
    }

    public void tick() {
        x += velX;
        y += velY;

        if (y <= 0 || y >= Game.HEIGHT - 32) {
            velY *= -1;//creating bounds of the window so that objects do not escape
        }
        if (x <= 0 || x >= Game.WIDTH - 16) {
            velX *= -1;
        }

        //handler.addObject(new Trail((int)x, (int)y, ID.Trail, Color.cyan, 16, 16, 0.03f, handler));//addition of enemy trail

    }

    public void render(Graphics g) {
        
        g.drawImage(enemy_image, (int)x, (int)y, null);
        
//        g.setColor(Color.cyan);//setting of enemy colour as red
//        g.fillRect((int)x, (int)y, 16, 16);//setting of enemy size of object to 16x16 pixels
    }

}
