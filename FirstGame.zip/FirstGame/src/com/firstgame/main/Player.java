/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import com.firstgame.main.Game.STATE;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

/**
 *
 * @author Angel
 */
public class Player extends GameObject {

    private Handler handler;
    private BufferedImage player_image;
    private Game game;

    public Player(int x, int y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

        SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);

        player_image = ss.takeImage(1, 1, 32, 32);
    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 32, 32);//hitbox using Rectangle
    }

    public void tick() {
        x += velX;
        y += velY;

        x = Game.clamp((int) x, 0, Game.WIDTH - 39);
        y = Game.clamp((int) y, 0, Game.HEIGHT - 58);

        //handler.addObject(new Trail((int) x, (int) y, ID.Player, Color.white, 32, 32, 0.07f, handler));//adding of player trail
        collision();
    }

    public void collision() {
        //method for collision detection
        for (int i = 0; i < handler.object.size(); i++) {//loops through every object in the object list
            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.BasicEnemy
                    || tempObject.getID() == ID.FastEnemy
                    || tempObject.getID() == ID.SmartEnemy
                    || tempObject.getID() == ID.BossEnemy) {//compares the id of every object to that of the enemy
                if (getBounds().intersects(tempObject.getBounds())) {//if the id's mathch it will reduce health by 2
                    HUD.HEALTH -= 2;
                }
            }
            if (tempObject.getID() == ID.HardEnemy) {
                if (getBounds().intersects(tempObject.getBounds())) {

                    HUD.HEALTH -= 4;
                }
            }
            if (tempObject.getID() == ID.PowerupHP) {
                if (getBounds().intersects(tempObject.getBounds())) {//if the id's mathch it will increase health by 50
                    HUD.HEALTH += 50;
                    handler.removeObject(tempObject);
                }
            }

        }
    }

    public void render(Graphics g) {

        g.drawImage(player_image, (int) x, (int) y, null);

//        g.setColor(Color.orange);//setting player colour as white
//        g.fillRect((int) x, (int) y, 32, 32);//setting playe size of object to 32x32 pixels
    }
}
