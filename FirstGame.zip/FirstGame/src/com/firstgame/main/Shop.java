/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author gel17835534
 */
public class Shop extends MouseAdapter {

    Handler handler;
    HUD hud;
    public int B1 = 1000;
    public int B2 = 1500;
    public int B3 = 500;

    public Shop(Handler handler, HUD hud) {
        this.handler = handler;
        this.hud = hud;
    }

    public void render(Graphics g) {

        g.setColor(Color.white);
        g.setFont(new Font("arial", 1, 40));
        g.drawString("Shop", Game.WIDTH / 2 - 48, 50);

        g.drawRect(150, 200, 100, 60);
        g.drawRect(350, 200, 100, 60);
        g.drawRect(550, 200, 100, 60);

        g.setColor(Color.red);
        g.setFont(new Font("arial", 1, 12));
        g.drawString("Upgrade Health", 158, 220);
        g.drawString("Cost: " + B1, 170, 250);

        g.setColor(Color.green);
        g.drawString("Refill Health", 368, 220);
        g.drawString("Cost: " + B2, 370, 250);

        g.setColor(Color.white);
        g.drawString("Upgrade Speed", 558, 220);
        g.drawString("Cost: " + B3, 573, 250);
        
        g.drawString("Score: " + hud.getScore(), 370, 350);
        g.drawString("Space to go back" , 353, 450);

    }

    public void mousePressed(MouseEvent e) {

        
        
    }

}
