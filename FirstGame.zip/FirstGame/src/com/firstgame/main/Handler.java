/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import com.firstgame.main.Game.STATE;
import java.awt.Graphics;
import java.util.LinkedList;

/**
 *
 * @author Angel
 */
public class Handler {
    //loops through every object then updates and renders them to the screen

    LinkedList<GameObject> object = new LinkedList<GameObject>();

    public void tick() {

        for (int i = 0; i < object.size(); i++) {//for loop that loops through every object

            GameObject tempObject = object.get(i);//sets temporary object to the id of the object the 
            //system is currently on
            tempObject.tick();//updates the object 

        }

    }

    public void clearEnemies() {
        for (int i = 0; i < object.size(); i++) {//for loop that loops through every object

            GameObject tempObject = object.get(i);//sets temporary object to the id of the object the 
            //system is currently on
            if (tempObject.getID() == ID.Player) {
                object.clear();
            } else if (tempObject.getID() != ID.Player) {
                object.remove(i);
            }

        }

    }

    public void render(Graphics g) {
        for (GameObject obj : object) {
            obj.render(g);
        }
    }

    public void addObject(GameObject object) {
        this.object.add(object);
    }

    public void removeObject(GameObject object) {
        this.object.remove(object);
    }

}
