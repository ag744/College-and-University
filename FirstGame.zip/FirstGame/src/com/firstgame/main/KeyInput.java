/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import com.firstgame.main.Game.STATE;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

/**
 *
 * @author Angel
 */
public class KeyInput extends KeyAdapter {

    private Handler handler;
    private boolean[] keyDown = new boolean[4];
    private Game game;

    public KeyInput(Handler handler, Game game) {
        this.handler = handler;

        this.game = game;
        keyDown[0] = false;
        keyDown[1] = false;
        keyDown[2] = false;
        keyDown[3] = false;
    }

    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();//gets the number value corresponding to the key

        for (int i = 0; i < handler.object.size(); i++) {

            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Player) {

                //Player controls using the arrow keys
                if (key == KeyEvent.VK_UP) {
                    tempObject.setVelY(-5);
                    keyDown[0] = true;
                }
                if (key == KeyEvent.VK_DOWN) {
                    tempObject.setVelY(5);
                    keyDown[1] = true;

                }
                if (key == KeyEvent.VK_RIGHT) {
                    tempObject.setVelX(5);
                    keyDown[2] = true;

                }
                if (key == KeyEvent.VK_LEFT) {
                    tempObject.setVelX(-5);
                    keyDown[3] = true;

                }
                if (key == KeyEvent.VK_ESCAPE) {
                    System.exit(0);//sets the "Esc" button on keyboard to exit out of the game
                }
                if (key == KeyEvent.VK_P) {
                    if (game.gameState == STATE.Game) {
                        if (Game.paused == false) {
                            Game.paused = true;
                        } else {
                            Game.paused = false;
                        }

                    }

                }
                if (key == KeyEvent.VK_SPACE) {
                    if (game.gameState == STATE.Game) {

                        game.gameState = STATE.Shop;

                    } else if (game.gameState == STATE.Shop) {
                        game.gameState = STATE.Game;
                    }
                }
            }

        }
    }

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();//gets the code for the key pressed

        for (int i = 0; i < handler.object.size(); i++) {

            GameObject tempObject = handler.object.get(i);

            if (tempObject.getID() == ID.Player) {

                //once released the player will no longer move until an arrow key is pressed again
                if (key == KeyEvent.VK_UP) {
                    keyDown[0] = false;
                }
                if (key == KeyEvent.VK_DOWN) {
                    keyDown[1] = false;
                }
                if (key == KeyEvent.VK_RIGHT) {
                    keyDown[2] = false;
                }
                if (key == KeyEvent.VK_LEFT) {
                    keyDown[3] = false;
                }
                //vertical movement stoppage
                if (!keyDown[0] && !keyDown[1]) {
                    tempObject.setVelY(0);
                }
                //horizontal movement stoppage
                if (!keyDown[2] && !keyDown[3]) {
                    tempObject.setVelX(0);
                }

            }
        }
    }
}
