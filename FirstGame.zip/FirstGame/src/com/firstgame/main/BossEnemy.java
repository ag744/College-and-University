/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.firstgame.main;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author Angel
 */
public class BossEnemy extends GameObject {

    private Handler handler;
    private Random r = new Random();
    private BufferedImage enemy_image;

    private int timer = 30;
    private int timer2 = 50;

    public BossEnemy(int x, int y, ID id, Handler handler) {
        super(x, y, id);

        this.handler = handler;

        velX = 0;
        velY = 3;
        
        SpriteSheet ss = new SpriteSheet(Game.sprite_sheet);
        
        enemy_image = ss.takeImage(3, 1, 64, 64);
    }

    public Rectangle getBounds() {
        return new Rectangle((int) x, (int) y, 64, 64);//creattion of hitboxes using Rectangle
    }

    public void tick() {

        x += velX;
        y += velY;

        if (timer <= 0) {
            velY = 0;
        } else {
            timer--;
        }

        if (timer <= 0) {
            timer2--;
        }

        if (timer2 <= 0) {
            if (velX == 0) {
                velX = 4;
            }
            if(velX > 0){
                velX += 0.05f;
            }
            else if(velX < 0){
                velX -= 0.05f;

            }
            velX = Game.clamp(velX, -10, 10);

            int spawn = r.nextInt(10);
            if (spawn == 0) {
                handler.addObject(new BossEnemyBullet((int)x + 32,(int) y + 32, ID.BasicEnemy, handler));
            }

        }

//        if (y <= 0 || y >= Game.HEIGHT - 80) {
//            velY *= -1;//creating bounds of the window so that objects do not escape
//        }
        if (x <= 0 || x >= Game.WIDTH - 68) {
            velX *= -1;
        }

        //handler.addObject(new Trail((int)x, (int)y, ID.Trail, Color.red, 64, 64, 0.9f, handler));//addition of enemy trail
    }

    public void render(Graphics g) {
        
        g.drawImage(enemy_image, (int)x, (int)y, null);
        
//        g.setColor(Color.red);//setting of enemy colour as red
//        g.fillRect((int) x, (int) y, 64, 64);//setting of enemy size of object to 16x16 pixels
    }

}
